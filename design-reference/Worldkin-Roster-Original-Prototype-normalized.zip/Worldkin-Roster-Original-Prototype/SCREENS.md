# Screen index (45 screens)

Open any screen at `http://127.0.0.1:4300/index.html#<route>`. Generated from the `W.def(...)` calls in `js/`.

| Code | Route | Screen | Group | Defined in |
|---|---|---|---|---|
| E01 | `#/a/overview` | Admin overview (role-specific) | Admin workspace | js/screens-admin.js |
| E02 | `#/a/verify` | Organization verification | Admin workspace | js/screens-admin.js |
| E03 | `#/a/users` | User management | Admin workspace | js/screens-admin.js |
| E04 | `#/a/moderation` | Content moderation | Admin workspace | js/screens-admin.js |
| E05 | `#/a/disputes` | Disputes & reviews | Admin workspace | js/screens-admin.js |
| E06 | `#/a/audit` | Audit log | Admin workspace | js/screens-admin.js |
| E07 | `#/a/access` | Admin access management | Admin workspace | js/screens-admin.js |
| B01 | `#/login/volunteer` | Volunteer sign in | Authentication | js/screens-auth.js |
| B02 | `#/login/org` | Organization sign in | Authentication | js/screens-auth.js |
| B03 | `#/admin/login` | Restricted admin sign in (+ MFA) | Authentication | js/screens-auth.js |
| B04–B06 | `#/register` | Registration (volunteer & organization) | Authentication | js/screens-auth.js |
| B07 | `#/otp` | Email verification code (OTP) | Authentication | js/screens-auth.js |
| B07 | `#/recover` | Password recovery | Authentication | js/screens-auth.js |
| A10 | `#/map` | Map discovery | Map & emergency | js/screens-map.js |
| A11 | `#/emergency` | Emergency volunteer network | Map & emergency | js/screens-map.js |
| A08 | `#/media` | Stories & media gallery | Media & community | js/screens-public.js |
| A09 | `#/video` | Video experience | Media & community | js/screens-public.js |
| D01 | `#/o/dashboard` | Organization overview | Organization workspace | js/screens-org.js |
| D02 | `#/o/opportunities` | Opportunity management | Organization workspace | js/screens-org.js |
| D03 | `#/o/create` | Create opportunity | Organization workspace | js/screens-org.js |
| D04 | `#/o/applicants` | Applicant management | Organization workspace | js/screens-org.js |
| D05 | `#/o/applicant` | Applicant details | Organization workspace | js/screens-org.js |
| D06 | `#/o/offers` | Offers & shifts | Organization workspace | js/screens-org.js |
| D07 | `#/o/attendance` | Attendance | Organization workspace | js/screens-org.js |
| D08 | `#/o/profile` | Organization profile & contact | Organization workspace | js/screens-org.js |
| D09 | `#/o/reports` | Reports & analytics | Organization workspace | js/screens-org.js |
| A01 | `#/home` | Homepage | Public website | js/screens-public.js |
| A02 | `#/discover` | Discover opportunities | Public website | js/screens-public.js |
| A03 | `#/opportunity` | Opportunity details | Public website | js/screens-public.js |
| A04 | `#/organizations` | Organizations directory | Public website | js/screens-public.js |
| A05 | `#/org-profile` | Organization trust profile | Public website | js/screens-public.js |
| A06 | `#/events` | Events | Public website | js/screens-public.js |
| A07 | `#/event` | Event details | Public website | js/screens-public.js |
| A12 | `#/about` | About, contact & legal | Public website | js/screens-public.js |
| — | `#/404` | Not found | System | js/screens-system.js |
| 00 | `#/system/index` | All screens (index) | System | js/screens-system.js |
| 01 · 09 | `#/system/components` | Design system & components | System | js/screens-system.js |
| 09 | `#/system/states` | Loading, empty, error, success, denied, 404, offline | System | js/screens-system.js |
| C01 | `#/v/dashboard` | Volunteer overview | Volunteer workspace | js/screens-volunteer.js |
| C02–C03 | `#/v/applications` | Applications & offers | Volunteer workspace | js/screens-volunteer.js |
| C04 | `#/v/calendar` | Calendar & agenda | Volunteer workspace | js/screens-volunteer.js |
| C05 | `#/v/passport` | Experience passport | Volunteer workspace | js/screens-volunteer.js |
| C06 | `#/v/certificates` | Certificates | Volunteer workspace | js/screens-volunteer.js |
| C07 | `#/v/notifications` | Notifications | Volunteer workspace | js/screens-volunteer.js |
| C08 | `#/v/profile` | Profile & settings | Volunteer workspace | js/screens-volunteer.js |
