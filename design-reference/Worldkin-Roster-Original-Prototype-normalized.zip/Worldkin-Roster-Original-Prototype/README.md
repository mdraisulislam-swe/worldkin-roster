# Worldkin Roster — original design prototype

This is the original, standalone HTML/CSS/JavaScript design prototype for Worldkin Roster (45 screens), exported unchanged from the folder that was served at `http://127.0.0.1:4300/index.html#/home`. It is a **design reference only**: every screen uses sample data, nothing is saved, and it makes no backend or API calls.

Only `README.md` and `SCREENS.md` were added for the export. All other files are byte-identical to the original.

## Run it locally

It needs a static web server, not a build step (no `npm install`, no dependencies).

**Python (what was used originally):**

```
cd Worldkin-Roster-Original-Prototype
python -m http.server 4300 --bind 127.0.0.1
```

Then open <http://127.0.0.1:4300/index.html#/home>.

**Node alternative:**

```
npx serve -l 4300 .
```

Opening `index.html` directly from the file system also mostly works. A local server is recommended so that the scripts load in the same way as the original.

## What is inside

| Path | Contents |
|---|---|
| `index.html` | Page shell: the prototype toolbar (Desktop / Tablet / Mobile toggle, "All screens" link), `#frame` and the `#app` mount point, and the script includes |
| `css/styles.css` | All design tokens (colours, type, radii, shadows), components, layouts and responsive rules |
| `js/app.js` | Hash router, global interactions (menus, tabs, toggles, modals, toasts) and the device-preview toggle |
| `js/ui.js` | Shared building blocks: public header and footer, workspace shells, cards, badges, modal and toast helpers |
| `js/icons.js` | Inline SVG icon set (no icon font or external icon files) |
| `js/data.js` | Sample data: organizations, opportunities, shifts, events, media, notifications and admin permissions |
| `js/screens-public.js` | Public website screens (home, discover, opportunity, organizations, events, media, about) |
| `js/screens-auth.js` | Sign-in, register, OTP and password-recovery screens |
| `js/screens-volunteer.js` | Volunteer workspace screens |
| `js/screens-org.js` | Organization workspace screens |
| `js/screens-admin.js` | Admin workspace screens (role-specific) |
| `js/screens-map.js` | Map discovery and emergency volunteer network |
| `js/screens-system.js` | Screen index, component gallery, system states, 404 |
| `SCREENS.md` | List of all 45 screens with code, route, group and source file |

**Navigation:** a hash router (`js/app.js`). Each screen is registered with `W.def('<route>', { code, group, title, render })`. **All screens** (`#/system/index`) lists every screen.

## Responsive layouts

- The toolbar's **Desktop / Tablet / Mobile** buttons resize the `#frame` element to 100%, 820 px and 390 px.
- The layouts respond to that frame through **CSS container queries** on the `app` container (`@container app`), with breakpoints at **1100 px**, **900 px** and **560 px**. The frame, not the browser window, decides the layout, so all three device layouts can be previewed on one screen.
- Narrowing a real browser window to these widths gives the same result.
- Mobile navigation: the header menu button toggles `#mobile-menu`.
- `prefers-reduced-motion` is respected.

## External resources (need an internet connection)

- **Fonts:** Inter and Manrope, loaded from Google Fonts (`fonts.googleapis.com` / `fonts.gstatic.com`) in `index.html`. Offline, the system sans-serif font is used instead.
- **Photos:** 9 sample photos are loaded by URL from `images.unsplash.com`. No image files are stored in the prototype. Offline, the photo areas stay empty, and the layout is otherwise unchanged.
- **Icons:** inline SVG in `js/icons.js`, so they work offline.

## Notes

- The data is sample data, and names marked "(Sample)" are fictional. Buttons that would change data only show a prototype message.
- The prototype contains no keys, credentials or environment files.
