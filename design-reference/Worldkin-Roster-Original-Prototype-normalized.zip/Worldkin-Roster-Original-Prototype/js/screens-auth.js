/* Section B — one authentication architecture, three role-specific entry screens. Nothing here authenticates. */
const authVisual = (kind) => {
  if (kind === 'admin') return `<div class="auth-visual auth-visual--admin">${W.logo(true)}
    <div class="stack gap-16 hide-sm"><span class="pin" style="width:56px;height:56px;background:rgba(255,255,255,.08)">${Ic('lock', 28)}</span><h2 class="h1" style="color:#fff">Restricted workspace</h2><p style="color:#b9c0c9;margin:0;max-width:380px">For authorized Worldkin administrators only. Access is logged and requires multi-factor verification.</p></div>
    <span class="caption" style="color:#8a929c">This page is not linked from the public site.</span></div>`
  const vol = kind === 'vol'
  return `<div class="auth-visual ${vol ? 'auth-visual--vol' : 'auth-visual--org'}">${W.logo(true)}
    <div class="photo hide-sm" style="position:absolute;inset:96px 40px 140px;border-radius:24px">${W.photo(vol ? 'hero' : 'team', '', '', 'position:absolute;inset:0')}</div>
    <div class="hero-float hide-sm" style="left:24px;top:46%;max-width:240px"><div class="row gap-8">${Ic(vol ? 'award' : 'shield-check', 20, 'verified')}<span class="small"><strong>${vol ? '4 hours verified' : 'Verified organization'}</strong><br><span class="caption">${vol ? 'Community kitchen · just now' : 'Reviewed before publishing'}</span></span></div></div>
    <div class="stack gap-8" style="position:relative"><h2 class="h2" style="color:#fff">${vol ? 'Help where it counts — and keep the proof.' : 'Recruit, coordinate and verify — in one place.'}</h2><p style="margin:0;color:#d6e7e0" class="small">${vol ? 'Join shifts, get selected, and build an experience passport confirmed by organizations.' : 'Publish opportunities, review applicants, run shifts and confirm hours.'}</p></div></div>`
}
const pwField = (id, label = 'Password', auto = 'current-password') => `<div class="field"><label class="label" for="${id}">${label}</label><div class="input-wrap">${Ic('lock')}<input id="${id}" class="input" type="password" autocomplete="${auto}" style="padding-right:52px"><span class="suffix"><button type="button" class="icon-btn" data-action="toggle-pw" aria-label="Show password" aria-pressed="false">${Ic('eye', 18)}</button></span></div></div>`

const loginForm = (kind, p) => {
  const err = p.state === 'error', loading = p.state === 'loading', org = kind === 'org'
  return `<div class="auth">${authVisual(org ? 'org' : 'vol')}<div class="auth-form"><form class="auth-form-inner" data-action="login" data-dest="${org ? '#/o/dashboard' : '#/v/dashboard'}" novalidate>
    <div><span class="eyebrow">${org ? 'Organization account' : 'Volunteer account'}</span><h1 class="h1 mt-8">Welcome back</h1><p class="muted" style="margin:6px 0 0">${org ? 'Sign in to manage your organization workspace.' : 'Sign in to see your shifts, offers and passport.'}</p></div>
    <div class="seg" role="group" aria-label="Account type"><a class="btn btn--sm ${org ? 'btn--ghost' : 'btn--secondary'}" href="#/login/volunteer" aria-current="${!org}">Volunteer</a><a class="btn btn--sm ${org ? 'btn--secondary' : 'btn--ghost'}" href="#/login/org" aria-current="${org}">Organization</a></div>
    ${err ? `<div class="alert alert--error" role="alert">${Ic('x-circle', 18)}<span>Email or password is incorrect. Check both and try again, or reset your password.</span></div>` : ''}
    <div class="field"><label class="label" for="em">${org ? 'Work email' : 'Email'}</label><div class="input-wrap">${Ic('mail')}<input id="em" class="input ${err ? 'is-invalid' : ''}" type="email" autocomplete="email" value="${err ? 'nadia@example.com' : ''}" placeholder="you@example.com"></div></div>
    ${pwField('pw')}
    <div class="row between wrap gap-8"><label class="checkbox"><input type="checkbox"> Keep me signed in on this device</label><a href="#/recover" class="link small">Forgot password?</a></div>
    <button class="btn btn--primary btn--lg btn--block" ${loading ? 'disabled' : ''}>${loading ? '<span class="spinner"></span>Signing in…' : 'Sign in'}</button>
    ${org ? `<div class="alert alert--info">${Ic('shield-check', 18)}<span>New organizations can sign in right away; publishing unlocks after Worldkin verifies your details.</span></div>` : ''}
    <p class="small muted" style="margin:0;text-align:center">${org ? 'New organization?' : 'New to Worldkin?'} <a href="#/register${org ? '?role=org' : ''}" class="link">Create an account</a></p>
    <div class="row gap-8 wrap" style="justify-content:center">${['', 'error', 'loading'].map((s) => `<a class="chip" style="height:28px;font-size:12px" aria-pressed="${(p.state || '') === s}" href="#/login/${org ? 'org' : 'volunteer'}${s ? '?state=' + s : ''}">${s || 'default'} state</a>`).join('')}</div>
  </form></div></div>`
}
W.def('/login/volunteer', { code: 'B01', group: 'Authentication', title: 'Volunteer sign in', render: (p) => loginForm('vol', p) })
W.def('/login/org', { code: 'B02', group: 'Authentication', title: 'Organization sign in', render: (p) => loginForm('org', p) })

W.def('/admin/login', { code: 'B03', group: 'Authentication', title: 'Restricted admin sign in (+ MFA)', render: (p) => {
  const step = p.step || 'password'
  const inner = step === 'denied' ? `<div class="stack gap-16" style="text-align:center;align-items:center"><span class="pin" style="width:64px;height:64px;background:var(--rose-50);color:var(--rose-700)">${Ic('lock', 30)}</span><h1 class="h2">Access denied</h1><p class="muted" style="margin:0">This account is not an authorized administrator. The attempt was recorded in the audit log.</p><a href="#/home" class="btn btn--secondary">Return to Worldkin</a></div>`
    : step === 'mfa' ? `<div><span class="eyebrow">Step 2 of 2 · Multi-factor</span><h1 class="h2 mt-8">Enter your authenticator code</h1><p class="muted small" style="margin:6px 0 0">Open your authenticator app and enter the 6-digit code for Worldkin Admin.</p></div>
      ${W.otpMarkup()}<button class="btn btn--primary btn--lg btn--block" data-action="admin-enter">Verify and continue</button><a href="#/admin/login" class="link small" style="text-align:center">Use a different account</a>`
    : `<div><span class="badge b-grey">${Ic('lock', 14)}Restricted</span><h1 class="h2 mt-12">Administrator sign in</h1><p class="muted small" style="margin:6px 0 0">Authorized staff only. Admin accounts cannot be created publicly.</p></div>
      <div class="field"><label class="label" for="aem">Admin email</label><div class="input-wrap">${Ic('mail')}<input id="aem" class="input" type="email" autocomplete="username"></div></div>${pwField('apw')}
      <a href="#/admin/login?step=mfa" class="btn btn--primary btn--lg btn--block">Continue</a>
      <div class="alert alert--warning">${Ic('alert', 18)}<span>Five failed attempts lock the account for 15 minutes. All sign-ins are audited.</span></div>`
  return `<div class="auth">${authVisual('admin')}<div class="auth-form"><div class="auth-form-inner">${inner}
    <div class="row gap-8 wrap" style="justify-content:center">${['password', 'mfa', 'denied'].map((s) => `<a class="chip" style="height:28px;font-size:12px" aria-pressed="${step === s}" href="#/admin/login?step=${s}">${s}</a>`).join('')}</div></div></div></div>`
} })

/* B04–B06 Registration: account type → details → verify email */
W.def('/register', { code: 'B04–B06', group: 'Authentication', title: 'Registration (volunteer & organization)', render: (p) => {
  const role = p.role === 'org' ? 'org' : p.role === 'vol' ? 'vol' : null, step = +(p.step || 1)
  const stepper = `<div class="steps" aria-label="Progress">${['Account type', 'Your details', 'Verify email'].map((s, i) => `${i ? '<span class="step-line"></span>' : ''}<span class="step ${i + 1 < step ? 'is-done' : i + 1 === step ? 'is-current' : ''}"><span class="dot">${i + 1 < step ? Ic('check', 14) : i + 1}</span><span class="desktop-only">${s}</span></span>`).join('')}</div>`
  let body
  if (step === 1) body = `<div><h1 class="h1">Join Worldkin Roster</h1><p class="muted" style="margin:6px 0 0">How would you like to take part?</p></div>
    <div class="stack gap-12" role="radiogroup" aria-label="Account type">
      ${[['vol', 'I want to volunteer', 'Find opportunities, apply, join shifts and build a verified experience passport.', 'heart', 'var(--sage-50)', 'var(--brand-700)'], ['org', 'I represent an organization', 'NGOs, charities, clubs and community groups. Publish after verification.', 'building', '#fbeee4', 'var(--terracotta-700)']]
      .map(([k, t, d, ic, bg, fg]) => `<a href="#/register?role=${k}" class="role-card" role="radio" aria-checked="${role === k}" style="text-decoration:none"><span class="ill" style="background:${bg};color:${fg}">${Ic(ic, 28)}</span><span class="stack gap-4"><strong>${t}</strong><span class="small muted">${d}</span></span>${role === k ? Ic('check-circle', 22, 'verified') : ''}</a>`).join('')}</div>
    <p class="caption" style="margin:0">Administrator accounts are never created here.</p>
    <a href="#/register?role=${role || 'vol'}&step=2" class="btn btn--primary btn--lg btn--block ${role ? '' : 'is-disabled'}" aria-disabled="${!role}">Continue</a>`
  else if (step === 2) body = role === 'org'
    ? `<div><h1 class="h2">Organization details</h1><p class="muted small" style="margin:6px 0 0">You’ll be the organization’s first admin. Documents are uploaded later, privately.</p></div>
      <div class="field"><label class="label" for="rn">Your full name</label><input id="rn" class="input" autocomplete="name"></div>
      <div class="field"><label class="label" for="ron">Organization name</label><input id="ron" class="input"></div>
      <div class="grid g-2"><div class="field"><label class="label" for="rot">Type</label><select id="rot" class="select"><option>NGO</option><option>Charity</option><option>University club</option><option>Community group</option></select></div><div class="field"><label class="label" for="roc">Country</label><select id="roc" class="select"><option>Bangladesh</option></select></div></div>
      <div class="field"><label class="label" for="re">Your sign-in email</label><input id="re" class="input" type="email"><span class="hint">Used to sign in. It is <strong>not</strong> published — you choose public contact details later.</span></div>
      ${pwField('rp', 'Password', 'new-password')}<span class="hint">At least 8 characters.</span>
      <a href="#/register?role=org&step=3" class="btn btn--primary btn--lg btn--block">Create account</a>`
    : `<div><h1 class="h2">Your details</h1><p class="muted small" style="margin:6px 0 0">Just the essentials — complete your profile after verifying your email.</p></div>
      <div class="field"><label class="label" for="rn">Full name</label><input id="rn" class="input" autocomplete="name"></div>
      <div class="field"><label class="label" for="re">Email</label><input id="re" class="input" type="email" autocomplete="email"></div>
      ${pwField('rp', 'Password', 'new-password')}<span class="hint">At least 8 characters.</span>
      <label class="checkbox"><input type="checkbox"> I agree to the <a href="#/about#terms" class="link">Terms</a> and <a href="#/about#privacy" class="link">Privacy policy</a></label>
      <a href="#/register?role=vol&step=3" class="btn btn--primary btn--lg btn--block">Create account</a>`
  else body = `<div class="stack gap-12" style="align-items:flex-start"><span class="pin" style="width:56px;height:56px;background:var(--sage-50);color:var(--brand-700)">${Ic('mail', 28)}</span><h1 class="h2">Check your email</h1><p class="muted" style="margin:0">We sent a 6-digit code to <strong>na••••@example.com</strong>. Enter it on the next screen to activate your account.</p>
    <a href="#/otp?next=${role === 'org' ? 'org' : 'vol'}" class="btn btn--primary btn--lg btn--block">Enter verification code</a><a href="#/register?role=${role}&step=2" class="link small">Change email</a></div>`
  return `<div class="auth">${authVisual(role === 'org' ? 'org' : 'vol')}<div class="auth-form"><div class="auth-form-inner">${stepper}${body}
    <p class="small muted" style="margin:0;text-align:center">Already registered? <a href="#/login/${role === 'org' ? 'org' : 'volunteer'}" class="link">Sign in</a></p></div></div></div>`
} })

/* B07 OTP */
W.otpMarkup = (state = '') => `<div><span class="label">Verification code</span><div class="otp mt-8 ${state === 'invalid' || state === 'expired' ? 'is-invalid' : state === 'success' ? 'is-valid' : ''}" role="group" aria-label="Verification code">${[...Array(6)].map((_, i) => `<input inputmode="numeric" maxlength="1" aria-label="Digit ${i + 1} of 6" ${i === 0 ? 'autocomplete="one-time-code"' : ''} value="${state === 'success' ? '482913'[i] : ''}">`).join('')}</div></div>`
W.otpMount = (root, onComplete) => {
  const boxes = [...root.querySelectorAll('.otp input')]
  boxes.forEach((b, i) => {
    b.addEventListener('input', () => { b.value = b.value.replace(/\D/g, '').slice(-1); if (b.value && boxes[i + 1]) boxes[i + 1].focus(); if (boxes.every((x) => x.value)) onComplete && onComplete(boxes.map((x) => x.value).join('')) })
    b.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !b.value && boxes[i - 1]) { boxes[i - 1].focus(); boxes[i - 1].value = '' } if (e.key === 'ArrowLeft' && boxes[i - 1]) boxes[i - 1].focus(); if (e.key === 'ArrowRight' && boxes[i + 1]) boxes[i + 1].focus() })
    b.addEventListener('paste', (e) => { e.preventDefault(); const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6); d.split('').forEach((c, j) => { if (boxes[j]) boxes[j].value = c }); (boxes[d.length] || boxes[5]).focus(); if (d.length === 6) onComplete && onComplete(d) })
  })
}
W.def('/otp', { code: 'B07', group: 'Authentication', title: 'Email verification code (OTP)', render: (p) => {
  const s = p.state || ''
  const msg = { invalid: ['error', 'x-circle', 'That code is incorrect. Check the newest email — only the latest code works.'], expired: ['warning', 'clock', 'This code has expired (codes last 60 minutes). Request a new one below.'], success: ['success', 'check-circle', 'Email verified — welcome to Worldkin! Taking you to your next step…'] }[s]
  return `<div class="auth">${authVisual(p.next === 'org' ? 'org' : 'vol')}<div class="auth-form"><div class="auth-form-inner">
    <div><span class="eyebrow">Step 3 of 3</span><h1 class="h1 mt-8">Verify your email</h1><p class="muted" style="margin:6px 0 0">We sent a 6-digit code to <strong>na••••@example.com</strong>.</p></div>
    ${msg ? `<div class="alert alert--${msg[0]}" role="${s === 'success' ? 'status' : 'alert'}">${Ic(msg[1], 18)}<span>${msg[2]}</span></div>` : ''}
    ${W.otpMarkup(s)}<span class="hint">Type or paste the code — it checks automatically when all 6 digits are in.</span>
    ${s === 'success' ? `<a href="${p.next === 'org' ? '#/o/profile' : '#/v/profile'}" class="btn btn--primary btn--lg btn--block">Continue to ${p.next === 'org' ? 'organization setup' : 'your profile'}</a>`
      : `<button class="btn btn--primary btn--lg btn--block" data-action="verify-otp">Verify email</button>
      <div class="row between wrap gap-8" style="border-top:var(--border);padding-top:14px"><span class="small muted">Didn’t get it? Check spam, or</span><button class="btn btn--ghost btn--sm" data-resend ${s === 'expired' ? '' : 'disabled'}>${s === 'expired' ? 'Resend code' : 'Resend code in <span data-cd>54</span>s'}</button></div>`}
    <a href="#/register?role=${p.next === 'org' ? 'org' : 'vol'}&step=2" class="link small">Change email</a>
    <div class="row gap-8 wrap" style="justify-content:center">${['', 'invalid', 'expired', 'success'].map((x) => `<a class="chip" style="height:28px;font-size:12px" aria-pressed="${s === x}" href="#/otp?state=${x}&next=${p.next || 'vol'}">${x || 'default'} state</a>`).join('')}</div>
  </div></div></div>`
}, mount: (root, p) => {
  W.otpMount(root, (code) => W.go(`#/otp?state=${code === '123456' ? 'success' : 'invalid'}&next=${p.next || 'vol'}`))
  root.querySelector('.otp input')?.focus()
  const cd = root.querySelector('[data-cd]'); if (cd) { let n = 54; const t = setInterval(() => { if (!document.body.contains(cd)) return clearInterval(t); n--; cd.textContent = n; if (n <= 0) { clearInterval(t); const b = root.querySelector('[data-resend]'); b.disabled = false; b.textContent = 'Resend code' } }, 1000) }
  root.querySelector('[data-action="verify-otp"]')?.addEventListener('click', () => W.toast('Enter all 6 digits (prototype: 123456 succeeds)', 'info'))
  root.querySelector('[data-resend]')?.addEventListener('click', (e) => { if (!e.target.disabled) W.toast('A new code would be sent (prototype — no email)', 'mail') })
} })

W.def('/recover', { code: 'B07', group: 'Authentication', title: 'Password recovery', render: (p) => {
  const s = p.step || 'request'
  const body = s === 'sent' ? `<span class="pin" style="width:56px;height:56px;background:var(--sage-50);color:var(--brand-700)">${Ic('mail', 28)}</span><h1 class="h2">Check your inbox</h1><p class="muted" style="margin:0">If an account exists for that email, a reset link is on its way. It expires in 60 minutes.</p><a href="#/recover?step=reset" class="btn btn--primary btn--block">Open reset link (prototype)</a>`
    : s === 'reset' ? `<h1 class="h2">Choose a new password</h1>${pwField('np', 'New password', 'new-password')}${pwField('np2', 'Confirm new password', 'new-password')}<span class="hint">At least 8 characters.</span><a href="#/recover?step=done" class="btn btn--primary btn--lg btn--block">Update password</a>`
    : s === 'done' ? `<span class="pin" style="width:56px;height:56px;background:var(--green-50);color:var(--green-800)">${Ic('check-circle', 28)}</span><h1 class="h2">Password updated</h1><p class="muted" style="margin:0">You can now sign in with your new password.</p><a href="#/login/volunteer" class="btn btn--primary btn--block">Sign in</a>`
    : `<h1 class="h2">Reset your password</h1><p class="muted" style="margin:0">Enter your account email and we’ll send a reset link.</p><div class="field"><label class="label" for="fe">Email</label><div class="input-wrap">${Ic('mail')}<input id="fe" class="input" type="email"></div></div><a href="#/recover?step=sent" class="btn btn--primary btn--lg btn--block">Send reset link</a>`
  return `<div class="auth">${authVisual('vol')}<div class="auth-form"><div class="auth-form-inner">${body}<a href="#/login/volunteer" class="link small">Back to sign in</a>
    <div class="row gap-8 wrap" style="justify-content:center">${['request', 'sent', 'reset', 'done'].map((x) => `<a class="chip" style="height:28px;font-size:12px" aria-pressed="${s === x}" href="#/recover?step=${x}">${x}</a>`).join('')}</div></div></div></div>`
} })
