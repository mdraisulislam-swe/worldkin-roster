/* Section C — Volunteer workspace */
const V = (active, content, title) => W.shell({ kind: 'volunteer', active, content, title })

W.def('/v/dashboard', { code: 'C01', group: 'Volunteer workspace', title: 'Volunteer overview', render: () => V('#/v/dashboard', `
  ${W.pageHead('Welcome back, Nadia', 'Your applications, offers, shifts and verified hours in one place.', `<a href="#/discover" class="btn btn--primary">${Ic('search', 18)}Find opportunities</a>`)}
  <div class="grid g-main-aside" style="align-items:start">
    <div class="card card-lg stack gap-12"><h2 class="h3">Next steps</h2>
      <div class="stack" style="gap:0">${[['briefcase', 'You have 1 offer waiting — it expires in 2 days 21 h.', 'Respond', '#/v/applications', true], ['user', 'Complete your profile (4/6): add languages and a photo.', 'Edit profile', '#/v/profile'], ['clock', '2 applications are being reviewed.', 'View', '#/v/applications']].map(([ic, t, c, h, a]) => `<div class="row between wrap gap-12" style="padding:12px 0;border-bottom:var(--border)"><span class="row gap-12 small" style="${a ? 'font-weight:600' : ''}">${Ic(ic, 18)}${t}</span><a href="${h}" class="btn ${a ? 'btn--primary' : 'btn--secondary'} btn--sm">${c}</a></div>`).join('')}</div></div>
    <div class="card card-lg stack gap-12"><div class="row between"><h2 class="h3">Profile</h2><span class="small muted">67%</span></div><div class="meter"><span style="width:67%"></span></div><span class="caption">Organizations see your skills and verified hours when you apply.</span><a href="#/v/profile" class="link small">Complete profile</a></div>
  </div>
  <div class="grid g-4 kpis">${W.kpi('Verified hours', '26', 'award', 'confirmed by orgs')}${W.kpi('Shifts attended', '7', 'check-circle', 'all time')}${W.kpi('Upcoming', '2', 'calendar', 'confirmed')}${W.kpi('Organizations helped', '3', 'building', 'all time')}</div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-12"><div class="row between"><h2 class="h3">Upcoming</h2><a href="#/v/calendar" class="link small">Open calendar</a></div>
      ${[['Today', 'Evening hotline', 'Online · 19:00–21:00', 'Confirmed'], ['Sat 28 Nov', 'Saturday morning packing', 'Mirpur, Dhaka · 09:00–13:00', 'Confirmed'], ['Mon 30 Nov', 'Mangrove planting day', 'Dacope, Khulna · 08:00–14:00', 'Waitlisted']].map(([d, t, m, s]) => `<div class="card card-pad row gap-16"><span class="stack" style="min-width:84px"><span class="caption" style="font-weight:600;color:var(--brand-700)">${d}</span></span><span class="stack" style="flex:1;min-width:0"><strong class="small">${t}</strong><span class="caption">${m}</span></span>${W.status(s)}</div>`).join('')}</div>
    <div class="stack gap-12"><div class="row between"><h2 class="h3">Recent updates</h2><a href="#/v/notifications" class="link small">All</a></div>
      <div class="card">${W.NOTIFS.slice(0, 3).map((n) => `<a href="${n.to}" class="row gap-12" style="padding:12px 16px;border-bottom:var(--border);text-decoration:none">${n.read ? '' : '<span class="dot-unread"></span>'}<span class="small" style="${n.read ? 'color:var(--ink-700)' : 'font-weight:600'}">${n.title}</span></a>`).join('')}</div>
      <h2 class="h3 mt-8">Recommended for you</h2>${W.oppCard(W.OPPS[1])}</div>
  </div>`, 'Volunteer workspace') })

W.def('/v/applications', { code: 'C02–C03', group: 'Volunteer workspace', title: 'Applications & offers', render: () => V('#/v/applications', `
  ${W.pageHead('Applications & offers', 'Respond to offers before they expire (72 hours).', '', W.crumbs([['Overview', '#/v/dashboard'], ['Applications']]))}
  <div class="card card-lg stack gap-12" style="border-color:var(--sky-700);background:var(--sky-50)"><div class="row wrap between gap-8"><span class="row gap-8">${Ic('briefcase', 20)}<strong>You have been selected: Climate literacy workshop facilitators</strong></span>${W.badge('Expires in 2 d 21 h', 'terra', 'clock')}</div>
    <span class="small">Green Delta Climate Action (Sample) · Tue 1 Dec · 15:00–17:00 · ${W.comp('Stipend')} BDT 1,500 per session</span>
    <div class="row gap-8 wrap"><button class="btn btn--primary" data-action="accept-offer">Accept offer</button><button class="btn btn--secondary" data-action="decline-offer">Decline</button></div>
    <span class="caption">Accepting books your seat safely. If the shift filled meanwhile, you’ll join the waitlist in order — never overbooked.</span></div>
  <div class="tabs" role="tablist">${['All', 'Pending', 'Offers', 'Accepted', 'Not selected', 'Withdrawn'].map((t, i) => `<button class="tab" role="tab" aria-selected="${i === 0}" data-tab="${t}">${t}<span class="n">${t === 'All' ? W.APPS.length : W.APPS.filter((a) => (t === 'Pending' ? ['Submitted', 'Under review'].includes(a.status) : t === 'Offers' ? a.status === 'Offer' : a.status === t)).length}</span></button>`).join('')}</div>
  <div class="card table-wrap"><table class="tbl tbl-cards"><thead><tr><th>Opportunity</th><th>Organization</th><th>Applied</th><th>Status</th><th></th></tr></thead><tbody data-rows>
  ${W.APPS.map((a) => { const o = W.opp(a.opp); return `<tr data-status="${a.status}"><td><a href="#/opportunity?id=${o.id}" class="link" style="font-weight:600">${o.title}</a>${a.note ? `<div class="caption">${a.note}</div>` : ''}</td><td data-hide-sm>${W.org(o.org).name}</td><td data-hide-sm>${a.applied}</td><td>${W.status(a.status)}</td><td data-hide-sm>${['Submitted', 'Under review'].includes(a.status) ? '<button class="btn btn--ghost btn--sm" data-action="withdraw">Withdraw</button>' : ''}</td></tr>` }).join('')}</tbody></table></div>`, 'Applications'), mount: (root) => {
  root.addEventListener('click', (e) => {
    const t = e.target.closest('[data-tab]'); if (t) { root.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', b === t)); const v = t.dataset.tab; root.querySelectorAll('[data-rows] tr').forEach((r) => { const s = r.dataset.status; r.hidden = !(v === 'All' || (v === 'Pending' && ['Submitted', 'Under review'].includes(s)) || (v === 'Offers' && s === 'Offer') || s === v) }) }
    if (e.target.closest('[data-action="accept-offer"]')) W.modal({ title: 'Accept this offer?', body: 'You’ll be booked onto <strong>Tue 1 Dec, 15:00–17:00</strong>. If the last seat was taken a moment ago, you’ll join the waitlist in order instead.', confirm: 'Accept offer', onConfirm: () => W.toast('Offer accepted — you’re confirmed (prototype)') })
    if (e.target.closest('[data-action="decline-offer"]')) W.modal({ title: 'Decline this offer?', body: 'The organization will be notified and may offer the seat to someone else. This can’t be undone.', confirm: 'Decline', danger: true, onConfirm: () => W.toast('Offer declined (prototype)', 'info') })
    if (e.target.closest('[data-action="withdraw"]')) W.modal({ title: 'Withdraw application?', body: 'You can apply again later while the opportunity is open.', confirm: 'Withdraw', danger: true, onConfirm: () => W.toast('Application withdrawn (prototype)', 'info') })
  })
} })

/* C04 Calendar */
const CAL_ITEMS = { 26: ['confirmed'], 28: ['confirmed', 'confirmed'], 30: ['waitlisted'], 1: ['deadline'], 21: ['past'], 15: ['past'] }
const CAL_COLOR = { confirmed: 'var(--brand-600)', waitlisted: '#d39b2a', deadline: 'var(--rose-700)', past: '#9aa3ad' }
W.def('/v/calendar', { code: 'C04', group: 'Volunteer workspace', title: 'Calendar & agenda', render: () => {
  const days = []; for (let i = 0; i < 42; i++) { const d = i - 5; days.push(d < 1 ? { n: 31 + d, out: true, key: null } : d > 30 ? { n: d - 30, out: true, key: d - 30 === 1 ? 1 : null } : { n: d, out: false, key: d }) }
  return V('#/v/calendar', `${W.pageHead('My calendar', 'Confirmed and waitlisted shifts, past participation and offer deadlines.', `<button class="btn btn--secondary" data-action="toast" data-msg="Calendar file (.ics) prepared — prototype">${Ic('download', 18)}Export</button>`)}
  <div class="grid g-main-aside" style="align-items:start">
    <div class="card card-pad"><div class="row between mb-16"><button class="icon-btn" aria-label="Previous month">${Ic('chevron-left')}</button><h2 class="h3">November 2026</h2><button class="icon-btn" aria-label="Next month">${Ic('chevron-right')}</button></div>
      <div class="cal" role="group" aria-label="November 2026">${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => `<span class="dow" aria-hidden="true">${d}</span>`).join('')}
      ${days.map((d) => { const items = (d.key && !d.out) || (d.out && d.key === 1) ? CAL_ITEMS[d.key] || [] : []; return `<button class="${d.out ? 'is-out' : ''} ${d.n === 26 && !d.out ? 'is-today' : ''}" aria-pressed="${d.n === 26 && !d.out}" data-day="${d.out ? 'o' + d.n : d.n}" aria-label="${d.n} ${d.out ? '' : 'November'}${items.length ? ', ' + items.length + ' items' : ''}">${d.n}<span class="dots">${items.map((k) => `<i style="background:${CAL_COLOR[k]}"></i>`).join('')}</span></button>` }).join('')}</div>
      <div class="legend mt-16">${[['Confirmed', 'confirmed'], ['Waitlisted', 'waitlisted'], ['Offer deadline', 'deadline'], ['Past', 'past']].map(([l, k]) => `<span><i style="background:${CAL_COLOR[k]}"></i>${l}</span>`).join('')}</div></div>
    <div class="stack gap-12" data-agenda></div>
  </div>`, 'Calendar')
}, mount: (root) => {
  const agenda = root.querySelector('[data-agenda]')
  const AG = { 26: [['19:00–21:00', 'Evening hotline', 'Dhaka Food Relief (Sample) · Online', 'Confirmed']], 28: [['09:00–13:00', 'Saturday morning packing', 'Mirpur, Dhaka', 'Confirmed'], ['14:00–16:00', 'Distribution team', 'Sunamganj', 'Confirmed']], 30: [['08:00–14:00', 'Mangrove planting day', 'Dacope, Khulna', 'Waitlisted']], o1: [['Expires 15:00', 'Answer your offer: Climate literacy facilitators', 'Green Delta (Sample)', 'Offer']], 21: [['09:00–13:00', 'Community kitchen', '4 hours verified', 'Attended']] }
  const show = (k) => { const items = AG[k] || []
    agenda.innerHTML = `<h2 class="h3">${k === 26 ? 'Today' : k === 'o1' ? 'Tue 1 December' : k + ' November'}</h2>` + (items.length ? items.map(([t, n, m, s]) => `<div class="card card-pad stack gap-8"><div class="row between gap-8"><span class="caption" style="font-weight:600">${t}</span>${W.status(s)}</div><strong class="small">${n}</strong><span class="caption">${m}</span>${['Confirmed', 'Waitlisted'].includes(s) ? `<button class="btn btn--ghost btn--sm" style="align-self:flex-start" data-action="toast" data-msg="Added to your calendar app (prototype)">${Ic('calendar', 16)}Add to calendar</button>` : ''}</div>`).join('') : `<div class="card">${W.empty('calendar', 'Nothing on this day', '', '<a href="#/events" class="btn btn--secondary btn--sm">Find an event</a>')}</div>`) }
  root.addEventListener('click', (e) => { const d = e.target.closest('[data-day]'); if (d) { root.querySelectorAll('[data-day]').forEach((b) => b.setAttribute('aria-pressed', b === d)); show(d.dataset.day) } })
  show(26)
} })

W.def('/v/passport', { code: 'C05', group: 'Volunteer workspace', title: 'Experience passport', render: () => V('#/v/passport', `
  ${W.pageHead('Verified experience passport', 'Hours and participation confirmed by organization staff — never self-reported.', `<button class="btn btn--secondary" data-action="toast" data-msg="Print dialog would open (prototype)">${Ic('download', 18)}Print / save PDF</button><button class="btn btn--ghost" disabled title="Public share link requires the certificate-verification module">${Ic('share', 18)}Share</button>`)}
  <div class="grid g-4 kpis">${W.kpi('Verified hours', '26', 'award', 'all time')}${W.kpi('Sessions attended', '7', 'check-circle', 'verified')}${W.kpi('Organizations', '3', 'building', 'verified')}${W.kpi('Certificates', '5', 'file-text', 'issued')}</div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="card card-lg"><div class="row between"><h2 class="h3">Verified hours per month</h2>${W.sample()}</div>${W.bars([0, 4, 6, 3, 9, 4], ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'])}<details class="mt-12"><summary class="link small">Show as table</summary><table class="tbl mt-8"><tbody>${[['Jun', 0], ['Jul', 4], ['Aug', 6], ['Sep', 3], ['Oct', 9], ['Nov', 4]].map(([m, h]) => `<tr><td>${m} 2026</td><td style="text-align:right">${h} h</td></tr>`).join('')}</tbody></table></details></div>
    <div class="card card-lg stack gap-12"><h2 class="h3">Skills &amp; languages</h2><span class="caption">Self-declared — not verified by organizations.</span><div class="chips">${['First aid', 'Bangla', 'English', 'Public speaking'].map((s) => `<span class="badge b-grey">${s}</span>`).join('')}</div></div>
  </div>
  <div class="stack gap-12"><h2 class="h3">Experience</h2>${[['Weekend food parcel packing', 'Dhaka Food Relief Network (Sample)', 'Voluntary · Food security · 3 Oct – 21 Nov 2026', '4 sessions', '14'], ['Mangrove planting day', 'Green Delta Climate Action (Sample)', 'Voluntary · Climate · 15 Nov 2026', '1 session', '6'], ['Reading circle assistant', 'Classroom Lights Education Trust (Sample)', 'Voluntary · Education · Aug 2026', '2 sessions', '6']].map(([t, o, m, s, h]) => `<div class="card card-pad row wrap between gap-12"><div class="stack gap-4"><strong>${t}</strong><span class="small">${o} <span class="verified">${Ic('shield-check', 14)}organization-verified</span></span><span class="caption">${m} · ${s}</span></div><span class="stat-num" style="font-size:26px">${h}<span class="small muted"> h</span></span></div>`).join('')}</div>`, 'Passport') })

W.def('/v/certificates', { code: 'C06', group: 'Volunteer workspace', title: 'Certificates', render: () => V('#/v/certificates', `
  ${W.pageHead('Certificates', 'Issued automatically for each verified participation.')}
  <div class="alert alert--info">${Ic('info', 18)}<span><strong>Public verification links</strong> (unique code / QR) are a planned feature (wk09) — not active yet. Today a certificate can be printed by its owner.</span></div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="card table-wrap"><table class="tbl tbl-cards"><thead><tr><th>Certificate</th><th>Issued</th><th>Hours</th><th>Status</th></tr></thead><tbody>
      ${[['Community kitchen', '21 Nov 2026', 4, 'Verified'], ['Mangrove planting day', '15 Nov 2026', 6, 'Verified'], ['Weekend food parcel packing', '7 Nov 2026', 3, 'Verified'], ['Reading circle assistant', '20 Aug 2026', 3, 'Verified']].map(([t, d, h, s], i) => `<tr><td><button class="link" style="font-weight:600" data-cert="${i}">${t}</button></td><td data-hide-sm>${d}</td><td>${h} h</td><td>${W.status(s)}</td></tr>`).join('')}</tbody></table></div>
    <div class="card card-lg stack gap-12" style="border:2px solid var(--sage-200)"><span class="eyebrow">Certificate of volunteering</span><span class="caption">Worldkin Roster · ${W.sample()}</span>
      <p class="small" style="margin:8px 0 0">This certifies that</p><span class="h2">Nadia Rahman</span><p class="small" style="margin:0">contributed <strong>4 verified hours</strong> to <strong>Community kitchen</strong> with Dhaka Food Relief Network (Sample) on 21 Nov 2026.</p>
      <span class="caption">Attendance confirmed by organization staff. Reference: 3a5f…df63</span>
      <div class="row gap-8"><button class="btn btn--primary btn--sm" data-action="toast" data-msg="Print dialog would open (prototype)">${Ic('download', 16)}Download PDF</button><span class="concept-tag">${Ic('sparkle', 12)}QR verification · planned</span></div></div>
  </div>`, 'Certificates') })

W.def('/v/notifications', { code: 'C07', group: 'Volunteer workspace', title: 'Notifications', render: () => V('#/v/notifications', `
  ${W.pageHead('Notifications', 'Decisions, offers, waitlist promotions and verified hours.', `<button class="btn btn--secondary" data-action="mark-all">Mark all as read</button>`)}
  <div class="tabs" role="tablist"><button class="tab" role="tab" aria-selected="true" data-f="all">All</button><button class="tab" role="tab" aria-selected="false" data-f="unread">Unread<span class="n" data-unread>${W.NOTIFS.filter((n) => !n.read).length}</span></button></div>
  <div class="card" data-list>${W.NOTIFS.map((n) => `<a href="${n.to}" class="row gap-16" data-n="${n.id}" data-read="${n.read}" style="padding:16px 20px;border-bottom:var(--border);text-decoration:none;${n.read ? '' : 'background:#f6fbf9'}">
    <span class="pin" style="background:var(--${n.tone === 'grey' ? 'neutral-100' : n.tone === 'brand' ? 'sage-50' : n.tone + '-50'});color:var(--${n.tone === 'grey' ? 'ink-700' : n.tone === 'brand' ? 'brand-700' : n.tone === 'green' ? 'green-800' : n.tone + '-700'})">${Ic(n.icon, 18)}</span>
    <span class="stack gap-4" style="flex:1;min-width:0"><span class="small" style="${n.read ? '' : 'font-weight:600'}">${n.read ? '' : '<span class="sr-only">Unread: </span>'}${n.title}</span><span class="caption">${n.body}</span></span><span class="caption" style="white-space:nowrap">${n.when}</span>${n.read ? '' : '<span class="dot-unread"></span>'}</a>`).join('')}</div>
  <p class="caption">${Ic('info', 12)} Opening a notification marks it as read. Email notifications are a separate, future capability.</p>`, 'Notifications'), mount: (root) => {
  const refresh = () => { const u = root.querySelectorAll('[data-read="false"]').length; root.querySelector('[data-unread]').textContent = u }
  root.querySelector('[data-action="mark-all"]').addEventListener('click', () => { root.querySelectorAll('[data-read="false"]').forEach((a) => { a.dataset.read = 'true'; a.style.background = ''; a.querySelector('.dot-unread')?.remove(); a.querySelector('.small').style.fontWeight = '' }); refresh(); W.toast('All notifications marked as read') })
  root.addEventListener('click', (e) => { const t = e.target.closest('[data-f]'); if (t) { root.querySelectorAll('[data-f]').forEach((b) => b.setAttribute('aria-selected', b === t)); root.querySelectorAll('[data-n]').forEach((a) => { a.hidden = t.dataset.f === 'unread' && a.dataset.read === 'true' }) } })
} })

W.def('/v/profile', { code: 'C08', group: 'Volunteer workspace', title: 'Profile & settings', render: () => V('#/v/profile', `
  ${W.pageHead('Profile & settings', 'Organizations see this when you apply. Your phone stays private.', '', W.crumbs([['Overview', '#/v/dashboard'], ['Profile']]))}
  <div class="grid g-main-aside" style="align-items:start">
    <form class="card card-lg stack gap-16" data-action="fake-submit">
      <div class="row gap-16">${W.avatar('NR', 72, true)}<div class="stack gap-4"><button type="button" class="btn btn--secondary btn--sm">${Ic('upload', 16)}Upload photo</button><span class="caption">PNG, JPG or WebP · up to 2 MB</span></div></div>
      <div class="grid g-2"><div class="field"><label class="label" for="pn">Full name</label><input id="pn" class="input" value="Nadia Rahman"></div><div class="field"><label class="label" for="pc">City</label><input id="pc" class="input" value="Dhaka"></div></div>
      <div class="field"><label class="label" for="pb">About you</label><textarea id="pb" class="textarea">Second-year student who loves teaching and community work.</textarea></div>
      <div class="field"><span class="label">Skills</span><div class="chips">${['First aid', 'Public speaking', 'Teaching', 'Design', 'Driving'].map((s, i) => `<button type="button" class="chip" aria-pressed="${i < 2}" data-action="toggle">${s}</button>`).join('')}</div></div>
      <div class="grid g-2"><div class="field"><label class="label" for="pl">Languages</label><input id="pl" class="input" placeholder="e.g. Bangla, English"></div><div class="field"><label class="label" for="pa">Availability</label><select id="pa" class="select"><option>Weekends</option><option>Weekday evenings</option></select></div></div>
      <div class="field"><label class="label" for="pp">Phone (private)</label><input id="pp" class="input" placeholder="+880…"><span class="hint">${Ic('lock', 12)} Only you and platform administrators can see this. Never shown to organizations.</span></div>
      <div class="row gap-8"><button class="btn btn--primary">Save profile</button><button type="button" class="btn btn--ghost">Cancel</button></div></form>
    <div class="stack gap-16"><div class="card card-pad stack gap-12"><h2 class="h4">Privacy</h2>
      ${[['Show my first name on public reviews', true], ['Let organizations I apply to see my verified hours', true], ['Join the emergency network (concept)', false]].map(([l, on]) => `<div class="row between gap-12"><span class="small">${l}</span><button class="switch" role="switch" aria-checked="${on}" data-action="switch" aria-label="${l}"></button></div>`).join('')}</div>
      <div class="card card-pad stack gap-8"><h2 class="h4">Account</h2><span class="small muted">Sign-in email: na••••@example.com</span><a href="#/recover" class="link small">Change password</a><button class="link small" style="color:var(--rose-700);text-align:left" data-action="confirm-delete">Delete account</button></div></div>
  </div>`, 'Profile') })
