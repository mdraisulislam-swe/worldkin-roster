/* Sample data only — fictional organizations, people and places. Nothing here is real or live. */
W.IMG = (id, w = 1200) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`
W.PHOTOS = {
  hero: 'photo-1559027615-cd4628902d4a',
  planting: 'photo-1542601906990-b4d3fb778b09',
  food: 'photo-1593113598332-cd288d649433',
  teaching: 'photo-1509062522246-3755977927d7',
  health: 'photo-1576091160550-2173dba999ef',
  team: 'photo-1517486808906-6ca8b3f04846',
  cleanup: 'photo-1618477461853-cf6ed80faba5',
  hands: 'photo-1488521787991-ed7bbaae773c',
  workshop: 'photo-1531482615713-2afd69097998',
  kids: 'photo-1488521787991-ed7bbaae773c',
}

W.ORGS = [
  { id: 'dfr', name: 'Dhaka Food Relief Network', short: 'DF', type: 'NGO', cause: 'Food security', city: 'Dhaka', verified: true, since: 'Nov 2026', opps: 6, events: 9, rating: 4.7, reviews: 18, photo: 'food',
    about: 'Community kitchens and food parcel distribution for low-income families. Volunteers pack, deliver and run weekend kitchens.' },
  { id: 'gdc', name: 'Green Delta Climate Action', short: 'GD', type: 'Community group', cause: 'Climate', city: 'Khulna', verified: true, since: 'Nov 2026', opps: 3, events: 4, rating: 4.8, reviews: 9, photo: 'planting',
    about: 'Mangrove restoration, climate literacy workshops and coastal clean-ups led by young people.' },
  { id: 'cle', name: 'Classroom Lights Education Trust', short: 'CL', type: 'Charity', cause: 'Education', city: 'Sylhet', verified: true, since: 'Oct 2026', opps: 4, events: 5, rating: 4.6, reviews: 12, photo: 'teaching',
    about: 'After-school tutoring, reading circles and exam mentoring for first-generation learners.' },
  { id: 'chc', name: 'Community Health Circle', short: 'CH', type: 'NGO', cause: 'Health', city: 'Chattogram', verified: true, since: 'Sep 2026', opps: 2, events: 3, rating: 4.9, reviews: 7, photo: 'health',
    about: 'Free health camps, blood-pressure screening and hygiene education in partnership with local clinics.' },
  { id: 'ucc', name: 'University Coastal Cleanup Club', short: 'UC', type: 'University club', cause: 'Environment', city: 'Cox’s Bazar', verified: false, since: 'Nov 2026', opps: 0, events: 0, rating: null, reviews: 0, photo: 'cleanup',
    about: 'Student-led beach and river clean-ups. Verification pending — cannot publish yet.' },
].map((o) => ({ ...o, name: o.name + ' (Sample)' }))

W.OPPS = [
  { id: 'o1', title: 'Weekend food parcel packing', org: 'dfr', cause: 'Food security', mode: 'On-site', city: 'Mirpur, Dhaka', comp: 'Voluntary', kind: 'Volunteer', select: 'Open sign-up', date: 'Sat 28 Nov', time: '09:00–13:00', capacity: 20, confirmed: 14, waitlist: 2, deadline: null, photo: 'food', skills: ['Packing', 'Teamwork'], cert: true },
  { id: 'o2', title: 'Mangrove planting day', org: 'gdc', cause: 'Climate', mode: 'On-site', city: 'Dacope, Khulna', comp: 'Voluntary', kind: 'Event', select: 'Open sign-up', date: 'Mon 30 Nov', time: '08:00–14:00', capacity: 40, confirmed: 20, waitlist: 0, deadline: null, photo: 'planting', skills: ['Outdoor work'], cert: true },
  { id: 'o3', title: 'Climate literacy workshop facilitators', org: 'gdc', cause: 'Education', mode: 'Hybrid', city: 'Khulna', comp: 'Stipend', compDetail: 'BDT 1,500 per session', kind: 'Fellowship', select: 'Application', date: 'Tue 1 Dec', time: '15:00–17:00', capacity: 4, confirmed: 2, waitlist: 0, deadline: 'Closes in 2 days', photo: 'workshop', skills: ['Public speaking', 'Bangla'], cert: true },
  { id: 'o4', title: 'Remote hotline interpreters', org: 'dfr', cause: 'Refugee support', mode: 'Remote', city: 'Online', comp: 'Voluntary', kind: 'Volunteer', select: 'Open sign-up', date: 'Today', time: '19:00–21:00', capacity: 6, confirmed: 1, waitlist: 0, deadline: null, photo: 'hands', skills: ['Rohingya', 'English'], cert: false },
  { id: 'o5', title: 'After-school maths tutor', org: 'cle', cause: 'Education', mode: 'On-site', city: 'Zindabazar, Sylhet', comp: 'Paid', compDetail: 'BDT 6,000 / month, part-time', kind: 'Part-time', select: 'Application', date: 'From 3 Dec', time: 'Mon–Wed 16:00–18:00', capacity: 3, confirmed: 1, waitlist: 0, deadline: 'Closes 5 Dec', photo: 'teaching', skills: ['Mathematics'], cert: true },
  { id: 'o6', title: 'Health camp registration desk', org: 'chc', cause: 'Health', mode: 'On-site', city: 'Agrabad, Chattogram', comp: 'Voluntary', kind: 'Event', select: 'Open sign-up', date: 'Sat 5 Dec', time: '08:30–15:00', capacity: 10, confirmed: 10, waitlist: 3, deadline: null, photo: 'health', skills: ['Data entry'], cert: true },
  { id: 'o7', title: 'Communications intern', org: 'cle', cause: 'Education', mode: 'Hybrid', city: 'Sylhet', comp: 'Stipend', compDetail: 'BDT 4,000 / month', kind: 'Internship', select: 'Application', date: 'Starts 10 Dec', time: '3 months · 12 h/week', capacity: 1, confirmed: 0, waitlist: 0, deadline: 'Closes 6 Dec', photo: 'team', skills: ['Writing', 'Design'], cert: true },
  { id: 'o8', title: 'Flood relief distribution support', org: 'dfr', cause: 'Disaster response', mode: 'On-site', city: 'Sunamganj', comp: 'Voluntary', kind: 'Volunteer', select: 'Open sign-up', date: 'Sat 28 Nov', time: '10:00–16:00', capacity: 8, confirmed: 7, waitlist: 0, deadline: null, photo: 'food', skills: ['First aid'], cert: true },
]

W.EVENTS = [
  { id: 'e1', opp: 'o4', title: 'Evening hotline', when: 'Today · 19:00–21:00', day: 0, status: 'now' },
  { id: 'e2', opp: 'o1', title: 'Saturday morning packing', when: 'Sat 28 Nov · 09:00–13:00', day: 2, status: 'upcoming' },
  { id: 'e3', opp: 'o8', title: 'Distribution team', when: 'Sat 28 Nov · 10:00–16:00', day: 2, status: 'upcoming' },
  { id: 'e4', opp: 'o2', title: 'Mangrove planting day', when: 'Mon 30 Nov · 08:00–14:00', day: 4, status: 'upcoming' },
  { id: 'e5', opp: 'o3', title: 'Climate literacy session 1', when: 'Tue 1 Dec · 15:00–17:00', day: 5, status: 'upcoming' },
  { id: 'e6', opp: 'o6', title: 'Agrabad health camp', when: 'Sat 5 Dec · 08:30–15:00', day: 9, status: 'upcoming' },
  { id: 'e7', opp: 'o1', title: 'Community kitchen', when: 'Sat 21 Nov · 09:00–13:00', day: -5, status: 'held' },
  { id: 'e8', opp: 'o2', title: 'River-bank clean-up', when: 'Sun 15 Nov · 07:00–11:00', day: -11, status: 'held' },
]

W.MEDIA = [
  { id: 'm1', type: 'photo', title: 'Planting 400 mangrove saplings', org: 'gdc', photo: 'planting', date: '15 Nov 2026', cause: 'Climate', h: 320 },
  { id: 'm2', type: 'video', title: 'A Saturday at the community kitchen', org: 'dfr', photo: 'food', date: '21 Nov 2026', cause: 'Food security', dur: '3:42', h: 220 },
  { id: 'm3', type: 'story', title: '“I came to help and found a team”', org: 'cle', photo: 'teaching', date: '12 Nov 2026', cause: 'Education', h: 260 },
  { id: 'm4', type: 'photo', title: 'Health camp: 210 screenings', org: 'chc', photo: 'health', date: '8 Nov 2026', cause: 'Health', h: 240 },
  { id: 'm5', type: 'video', title: 'How a climate workshop runs', org: 'gdc', photo: 'workshop', date: '2 Nov 2026', cause: 'Education', dur: '5:10', h: 300 },
  { id: 'm6', type: 'photo', title: 'Packing day volunteers', org: 'dfr', photo: 'team', date: '31 Oct 2026', cause: 'Food security', h: 210 },
]

W.NOTIFS = [
  { id: 'n1', icon: 'briefcase', tone: 'sky', title: 'You have been selected: Climate literacy workshop facilitators', body: 'Accept or decline within 72 hours.', when: '10 min ago', read: false, to: '#/v/applications' },
  { id: 'n2', icon: 'check-circle', tone: 'green', title: 'A seat opened up — you are confirmed', body: 'Weekend food parcel packing · Sat 28 Nov', when: '2 h ago', read: false, to: '#/v/calendar' },
  { id: 'n3', icon: 'award', tone: 'brand', title: '4 volunteer hours verified', body: 'Community kitchen · Dhaka Food Relief Network (Sample)', when: 'Yesterday', read: true, to: '#/v/passport' },
  { id: 'n4', icon: 'info', tone: 'grey', title: 'Your application is under review', body: 'After-school maths tutor', when: '2 days ago', read: true, to: '#/v/applications' },
]

W.APPS = [
  { opp: 'o3', status: 'Offer', applied: '20 Nov', note: 'Offer expires in 2 days 21 h' },
  { opp: 'o5', status: 'Under review', applied: '22 Nov' },
  { opp: 'o7', status: 'Submitted', applied: '25 Nov' },
  { opp: 'o6', status: 'Not selected', applied: '10 Nov', note: 'Positions filled' },
  { opp: 'o2', status: 'Withdrawn', applied: '5 Nov' },
]

W.APPLICANTS = [
  { id: 'a1', name: 'Nadia R.', hours: 26, skills: ['Public speaking', 'Bangla'], status: 'Submitted', applied: '25 Nov', match: 2 },
  { id: 'a2', name: 'Tanvir H.', hours: 8, skills: ['Bangla', 'Design'], status: 'Under review', applied: '24 Nov', match: 1 },
  { id: 'a3', name: 'Farhana K.', hours: 41, skills: ['Public speaking', 'Teaching'], status: 'Offer sent', applied: '22 Nov', match: 1 },
  { id: 'a4', name: 'Imran S.', hours: 0, skills: ['English'], status: 'Submitted', applied: '26 Nov', match: 0 },
  { id: 'a5', name: 'Sadia M.', hours: 15, skills: ['Bangla'], status: 'Not selected', applied: '19 Nov', match: 1 },
]

W.ADMINS = { super: 'Super Admin', verify: 'Verification Admin', moderate: 'Moderation Admin' }
/* Permission matrix — which admin screens each role may open (deny by default). */
W.ADMIN_PERMS = {
  overview: ['super', 'verify', 'moderate'],
  verify: ['super', 'verify'],
  users: ['super'],
  moderation: ['super', 'moderate'],
  disputes: ['super', 'moderate'],
  audit: ['super', 'verify', 'moderate'],
  access: ['super'],
}

W.CONTACT_STATES = {
  A: { label: 'A · Email, phone and website', email: 'hello@dhakafoodrelief.example', phone: '+880 1700 000 000', website: 'dhakafoodrelief.example', address: 'House 12, Road 4, Mirpur 10, Dhaka', social: { facebook: true, instagram: true } },
  B: { label: 'B · Email only', email: 'contact@greendelta.example' },
  C: { label: 'C · Website only', website: 'classroomlights.example' },
  D: { label: 'D · No public contact', },
  E: { label: 'E · Recently updated', email: 'volunteer@communityhealth.example', phone: '+880 1800 000 000', website: 'communityhealth.example', updated: 'Updated 2 hours ago' },
}

W.org = (id) => W.ORGS.find((o) => o.id === id)
W.opp = (id) => W.OPPS.find((o) => o.id === id)
