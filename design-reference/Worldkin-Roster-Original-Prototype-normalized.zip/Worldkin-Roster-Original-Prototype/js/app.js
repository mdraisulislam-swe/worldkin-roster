/* Hash router, global interactions and prototype controls. No network calls, no storage of personal data. */
W.state = { adminRole: 'super', device: 'desktop' }
W.go = (hash) => { location.hash = hash.replace(/^#?/, '#') }

const parse = () => {
  const raw = location.hash.replace(/^#/, '') || '/home'
  const [path, qs] = raw.split('?')
  const params = Object.fromEntries(new URLSearchParams(qs || ''))
  if (path === '/admin/login' || path.startsWith('/a/')) Object.assign(params, {})
  return { path: path.split('#')[0], params }
}

const render = () => {
  const { path, params } = parse()
  const spec = W.routes[path] || W.routes['/404']
  const app = document.getElementById('app')
  app.innerHTML = spec.render(params)
  document.title = `${spec.title} · Worldkin Roster prototype`
  document.querySelectorAll('[data-icon]').forEach((el) => { el.innerHTML = W.icon(el.dataset.icon, 16) })
  if (spec.mount) spec.mount(app, params)
  else if (app.querySelector('.otp')) W.otpMount(app)
  window.scrollTo(0, 0); document.getElementById('frame').scrollTop = 0
  const h1 = app.querySelector('h1'); if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }) }
}

/* Global, delegated interactions shared by every screen */
document.addEventListener('click', (e) => {
  const a = e.target.closest('[data-action]'); if (!a) return
  const act = a.dataset.action
  if (act === 'toast') W.toast(a.dataset.msg || 'Done (prototype)', 'info')
  if (act === 'toggle-menu') { const m = document.getElementById('mobile-menu'); m.hidden = !m.hidden; a.setAttribute('aria-expanded', String(!m.hidden)) }
  if (act === 'toggle-pw') { const inp = a.closest('.input-wrap').querySelector('input'); const show = inp.type === 'password'; inp.type = show ? 'text' : 'password'; a.setAttribute('aria-pressed', String(show)); a.setAttribute('aria-label', show ? 'Hide password' : 'Show password'); a.innerHTML = W.icon(show ? 'eye-off' : 'eye', 18) }
  if (act === 'switch') a.setAttribute('aria-checked', String(a.getAttribute('aria-checked') !== 'true'))
  if (act === 'toggle') a.setAttribute('aria-pressed', String(a.getAttribute('aria-pressed') !== 'true'))
  if (act === 'seg') a.parentNode.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b === a)))
  if (act === 'org-switch') W.modal({ title: 'Switch organization', body: `<div class="stack gap-8">${['Dhaka Food Relief Network (Sample) · Admin', 'Green Delta Climate Action (Sample) · Admin'].map((o, i) => `<label class="role-card" style="padding:12px"><input type="radio" name="os" ${i === 0 ? 'checked' : ''}> <span class="small">${o}</span></label>`).join('')}</div>`, confirm: 'Switch', onConfirm: () => W.toast('Switched organization (prototype)') })
  if (act === 'admin-enter') W.go('#/a/overview')
  if (act === 'demo-modal') W.modal({ title: 'Cancel your place?', body: 'If the shift is full, your seat goes to the first person on the waitlist.', confirm: 'Cancel my place', danger: true, onConfirm: () => W.toast('Place cancelled (prototype)', 'info') })
  if (act === 'confirm-delete') W.modal({ title: 'Delete account?', body: 'Your verified participation records stay with the organizations for their audit. This cannot be undone.', confirm: 'Delete account', danger: true, onConfirm: () => W.toast('Prototype — nothing was deleted', 'info') })
})
/* Generic tabs without their own handler: just move the selection */
document.addEventListener('click', (e) => { const t = e.target.closest('.tab'); if (t && !t.dataset.tab && !t.dataset.f && !t.dataset.pt) t.parentNode.querySelectorAll('.tab').forEach((b) => b.setAttribute('aria-selected', String(b === t))) })
document.addEventListener('submit', (e) => {
  const f = e.target; e.preventDefault()
  if (f.dataset.action === 'hero-search') return W.go('#/discover')
  if (f.dataset.action === 'login') { const btn = f.querySelector('button.btn--primary'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Signing in…'; setTimeout(() => W.go(f.dataset.dest), 700); return }
  W.toast('Saved (prototype — nothing is stored)')
})
document.addEventListener('change', (e) => { if (e.target.dataset.action === 'admin-role') { W.state.adminRole = e.target.value; render() } })

/* Device preview toggle (prototype chrome) */
document.querySelectorAll('[data-device]').forEach((b) => b.addEventListener('click', () => {
  W.state.device = b.dataset.device
  document.querySelectorAll('[data-device]').forEach((x) => x.setAttribute('aria-pressed', String(x === b)))
  document.getElementById('frame').className = 'frame frame--' + b.dataset.device
  render()
}))

window.addEventListener('hashchange', render)
render()
