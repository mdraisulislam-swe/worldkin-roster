/* A10 Map discovery + A11 Emergency network. Fictional sample district — no real geography. */
W.MAP_POINTS = [
  { id: 'p1', kind: 'opp', x: 300, y: 250, title: 'Weekend food parcel packing', sub: 'Dhaka Food Relief (Sample)', area: 'North Market area', avail: '6 seats left', date: 'Sat 28 Nov', to: '#/opportunity?id=o1' },
  { id: 'p2', kind: 'event', x: 560, y: 330, title: 'Climate literacy session 1', sub: 'Green Delta (Sample)', area: 'Riverside', avail: '2 seats left', date: 'Tue 1 Dec', to: '#/event?id=e5' },
  { id: 'p3', kind: 'org', x: 720, y: 190, title: 'Community Health Circle (Sample)', sub: 'NGO · Health', area: 'Hill Gardens', avail: '2 open opportunities', date: 'Verified', to: '#/org-profile?id=chc' },
  { id: 'p4', kind: 'opp', x: 430, y: 470, title: 'After-school maths tutor', sub: 'Classroom Lights (Sample)', area: 'Old Town', avail: '2 seats left', date: 'From 3 Dec', to: '#/opportunity?id=o5' },
  { id: 'p5', kind: 'event', x: 820, y: 470, title: 'Agrabad health camp', sub: 'Community Health (Sample)', area: 'Harbour', avail: 'Full · waitlist open', date: 'Sat 5 Dec', to: '#/event?id=e6' },
  { id: 'p6', kind: 'org', x: 210, y: 520, title: 'Classroom Lights Education Trust (Sample)', sub: 'Charity · Education', area: 'West Park', avail: '4 open opportunities', date: 'Verified', to: '#/org-profile?id=cle' },
]
const KIND = { opp: ['Opportunity', '#0f5e57', 'briefcase'], event: ['Event', '#a9531c', 'calendar'], org: ['Organization', '#0c3b36', 'building'] }

W.mapSvg = ({ points = W.MAP_POINTS, active = null, areas = false, clusters = true } = {}) => `
<svg class="map-svg" viewBox="0 0 1000 700" role="img" aria-label="Sample district map with ${points.length} markers" preserveAspectRatio="xMidYMid slice">
  <rect width="1000" height="700" fill="#eef0ea"/>
  <!-- blocks -->
  <g fill="#e4e7e0">${[[60, 60, 180, 120], [270, 60, 200, 110], [520, 50, 170, 90], [760, 60, 190, 80], [60, 230, 150, 150], [620, 400, 140, 120], [60, 600, 260, 70], [480, 580, 200, 90], [800, 560, 150, 110]].map(([x, y, w, h]) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="6"/>`).join('')}</g>
  <!-- parks -->
  <g fill="#d3e6d3"><path d="M120 420 q60-40 120 0 t60 90 l-40 50 q-90 20-150-30z"/><rect x="660" y="140" width="140" height="100" rx="18"/><circle cx="905" cy="300" r="55"/></g>
  <!-- river -->
  <path d="M-20 640 C150 600 220 560 330 560 S520 610 600 540 S760 380 860 360 S980 330 1020 300" fill="none" stroke="#bcd8e6" stroke-width="38" stroke-linecap="round"/>
  <!-- major roads -->
  <g fill="none" stroke-linecap="round"><g stroke="#d6d9d1" stroke-width="22"><path d="M0 200 H1000"/><path d="M380 0 V700"/><path d="M0 390 C300 380 600 420 1000 430"/></g>
    <g stroke="#ffffff" stroke-width="16"><path d="M0 200 H1000"/><path d="M380 0 V700"/><path d="M0 390 C300 380 600 420 1000 430"/></g>
  <!-- minor roads -->
    <g stroke="#ffffff" stroke-width="7"><path d="M150 0 V700"/><path d="M600 0 V520"/><path d="M820 0 V700"/><path d="M0 110 H1000"/><path d="M0 300 H380"/><path d="M380 520 H1000"/><path d="M600 260 L820 140"/><path d="M150 470 L380 470"/></g></g>
  <!-- bridge -->
  <path d="M368 540 h24 v60 h-24z" fill="#ffffff" stroke="#d6d9d1"/>
  <!-- labels -->
  <g font-family="Inter, sans-serif" font-size="13" fill="#6b7480" font-weight="500">
    <text x="470" y="194">Station Road</text><text x="388" y="80" transform="rotate(90 388 80)">Central Avenue</text><text x="40" y="378">Riverside Boulevard</text>
    <text x="156" y="160" transform="rotate(90 156 160)">Mill Lane</text><text x="826" y="250" transform="rotate(90 826 250)">Harbour Street</text><text x="640" y="104">Garden Row</text>
  </g>
  <g font-family="Manrope, sans-serif" font-size="15" font-weight="700" fill="#8a929c" letter-spacing="2">
    <text x="300" y="150">NORTH MARKET</text><text x="680" y="270">HILL GARDENS</text><text x="430" y="660">OLD TOWN</text><text x="150" y="600" >WEST PARK</text><text x="840" y="620">HARBOUR</text><text x="540" y="470" font-size="13" fill="#7aa7bd">Kin River</text>
  </g>
  ${areas ? `<g fill="rgba(200,105,46,.12)" stroke="#c8692e" stroke-dasharray="6 6" stroke-width="2"><circle cx="330" cy="280" r="120"/><circle cx="760" cy="420" r="150"/></g>
    <g font-family="Inter" font-size="13" font-weight="600" fill="#a9531c"><text x="250" y="420">~5 km area · 14 opted-in</text><text x="680" y="590">~5 km area · 9 opted-in</text></g>` : ''}
  ${clusters ? `<g class="marker" tabindex="0" data-cluster><circle class="ring" cx="120" cy="140" r="22" fill="#2f8f6a" stroke="#fff" stroke-width="3"/><text x="120" y="145" text-anchor="middle" font-family="Manrope" font-weight="700" font-size="14" fill="#fff">5</text></g>
    <g class="marker" tabindex="0" data-cluster><circle class="ring" cx="930" cy="160" r="20" fill="#2f8f6a" stroke="#fff" stroke-width="3"/><text x="930" y="165" text-anchor="middle" font-family="Manrope" font-weight="700" font-size="13" fill="#fff">3</text></g>` : ''}
  ${points.map((p) => { const [l, c] = KIND[p.kind]; const shape = p.kind === 'org' ? `<rect class="ring" x="${p.x - 17}" y="${p.y - 17}" width="34" height="34" rx="9" fill="${c}" stroke="#fff" stroke-width="3"/>` : `<circle class="ring" cx="${p.x}" cy="${p.y}" r="17" fill="${c}" stroke="#fff" stroke-width="3"/>`
    return `<g class="marker ${active === p.id ? 'is-active' : ''}" tabindex="0" role="button" data-pt="${p.id}" aria-label="${l}: ${p.title}">${shape}<g transform="translate(${p.x - 9} ${p.y - 9}) scale(.75)" stroke="#fff" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${W.ICONS[KIND[p.kind][2]]}</g></g>` }).join('')}
</svg>`

const resultCard = (p, active) => { const [l, c, ic] = KIND[p.kind]
  return `<button class="result ${active ? 'is-active' : ''}" data-pt="${p.id}"><span class="pin" style="background:${c}">${W.icon(ic, 18)}</span><span class="stack gap-4" style="min-width:0"><span class="caption" style="font-weight:600;color:${c}">${l}</span><strong class="small">${p.title}</strong><span class="caption">${p.sub} · ${p.area}</span><span class="caption">${p.date} · <strong>${p.avail}</strong></span></span></button>` }

W.def('/map', { code: 'A10', group: 'Map & emergency', title: 'Map discovery', render: () => W.publicPage('#/map', `
<section class="section--tight"><div class="container stack gap-16">
  <div class="row wrap between gap-12"><div>${W.crumbs([['Discover', '#/discover'], ['Map']])}<h1 class="h2">Explore on the map</h1></div>
    <div class="row gap-8">${W.concept('Map is a concept · needs location data (wk12)')}${W.sample('Fictional sample district')}</div></div>
  <div class="card card-pad row wrap gap-12">
    <div class="input-wrap" style="flex:2;min-width:200px">${Ic('search')}<label class="sr-only" for="ma">Search by area</label><input id="ma" class="input" placeholder="Search an area, e.g. Old Town"></div>
    <div class="chips" role="group" aria-label="Show">${[['all', 'All'], ['opp', 'Opportunities'], ['event', 'Events'], ['org', 'Organizations']].map(([k, l], i) => `<button class="chip" data-kind="${k}" aria-pressed="${i === 0}">${l}</button>`).join('')}</div>
    <select class="select" style="width:auto" aria-label="Distance"><option>Within 5 km</option><option>Within 10 km</option><option>Anywhere</option></select>
    <div class="seg mobile-only" role="group" aria-label="View"><button data-view="map" aria-pressed="true">${Ic('map', 16)}Map</button><button data-view="list" aria-pressed="false">${Ic('list', 16)}List</button></div>
  </div>
  <div class="map-layout">
    <div class="map-results" data-list aria-label="Results">${W.MAP_POINTS.map((p) => resultCard(p)).join('')}</div>
    <div class="map-wrap" data-map>${W.mapSvg()}
      <div class="map-ctrl"><button aria-label="Zoom in" data-zoom="1">${Ic('plus', 18)}</button><button aria-label="Zoom out" data-zoom="-1">${Ic('minus', 18)}</button><button aria-label="Use my approximate location" data-action="toast" data-msg="Location is used only for this search and never stored (concept)">${Ic('locate', 18)}</button></div>
      <div class="map-legend">${Object.values(KIND).map(([l, c]) => `<span class="row gap-4"><i style="width:10px;height:10px;border-radius:50%;background:${c};display:inline-block"></i>${l}</span>`).join('')}<span class="row gap-4"><i style="width:10px;height:10px;border-radius:50%;background:#2f8f6a;display:inline-block"></i>Cluster</span></div>
      <div class="map-preview" data-preview hidden></div>
    </div>
  </div>
  <p class="caption">${Ic('info', 12)} Available seats = capacity minus confirmed participants (waitlist not counted). Markers show approximate areas; exact addresses of volunteers are never shown.</p>
</div></section>`), mount: (root) => {
  let kind = 'all', active = null, zoom = 1
  const map = root.querySelector('[data-map]'), list = root.querySelector('[data-list]'), prev = root.querySelector('[data-preview]')
  const draw = () => {
    const pts = W.MAP_POINTS.filter((p) => kind === 'all' || p.kind === kind)
    map.querySelector('svg').outerHTML = W.mapSvg({ points: pts, active, clusters: kind === 'all' })
    map.querySelector('svg').style.transform = `scale(${zoom})`; map.querySelector('svg').style.transformOrigin = 'center'
    list.innerHTML = pts.length ? pts.map((p) => resultCard(p, p.id === active)).join('') : W.empty('map-pin', 'No results in this area', 'Try a wider distance or another area.')
    const p = W.MAP_POINTS.find((x) => x.id === active)
    prev.hidden = !p
    if (p) prev.innerHTML = `<div class="card card-pad stack gap-8" style="box-shadow:var(--shadow-2)"><div class="row between"><span class="caption" style="font-weight:600;color:${KIND[p.kind][1]}">${KIND[p.kind][0]}</span><button class="icon-btn" style="width:28px;height:28px" data-close aria-label="Close">${Ic('x', 16)}</button></div><strong>${p.title}</strong><span class="caption">${p.sub}</span><span class="caption">${Ic('map-pin', 12)} ${p.area} (approximate) · ${p.date}</span><span class="badge b-green" style="align-self:flex-start">${p.avail}</span><a href="${p.to}" class="btn btn--primary btn--sm">View details</a></div>`
  }
  root.addEventListener('click', (e) => {
    const k = e.target.closest('[data-kind]'); if (k) { root.querySelectorAll('[data-kind]').forEach((b) => b.setAttribute('aria-pressed', b === k)); kind = k.dataset.kind; active = null; draw() }
    const pt = e.target.closest('[data-pt]'); if (pt) { active = pt.dataset.pt; draw() }
    if (e.target.closest('[data-cluster]')) W.toast('Cluster of nearby items — zoom in to separate them', 'layers')
    if (e.target.closest('[data-close]')) { active = null; draw() }
    const z = e.target.closest('[data-zoom]'); if (z) { zoom = Math.min(1.8, Math.max(1, zoom + 0.2 * +z.dataset.zoom)); draw() }
    const v = e.target.closest('[data-view]'); if (v) { root.querySelectorAll('[data-view]').forEach((b) => b.setAttribute('aria-pressed', b === v)); const isList = v.dataset.view === 'list'; map.hidden = isList; list.style.display = isList ? 'flex' : '' }
  })
  root.addEventListener('keydown', (e) => { const pt = e.target.closest('[data-pt]'); if (pt && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); active = pt.dataset.pt; draw() } })
  /* On mobile, list is hidden until "List" is chosen. */
  if (root.closest('.frame--mobile')) list.style.display = 'none'
} })

W.def('/emergency', { code: 'A11', group: 'Map & emergency', title: 'Emergency volunteer network', render: () => W.publicPage('#/emergency', `
<section class="section--tight"><div class="container stack gap-24">
  <div>${W.crumbs([['Home', '#/home'], ['Emergency volunteer network']])}<div class="row wrap gap-8 mb-8">${W.concept('Future module · proposal only (wk12-B)')}</div><h1 class="h1">Emergency volunteer network</h1>
    <p class="lead" style="margin:8px 0 0">When a verified organization needs urgent local help, opted-in volunteers nearby can say they’re available.</p></div>
  <div class="alert alert--error" role="note">${Ic('siren', 20)}<span><strong>Worldkin Roster is not an emergency service.</strong> In an emergency, contact your local emergency number first. This network only helps verified organizations find willing volunteers.</span></div>
  <div class="grid g-3">${[['user', 'You opt in', 'Off by default. Choose skills, availability and an approximate area — never your exact address.'], ['shield-check', 'Verified requests only', 'Only verified organizations can post, with rate limits and an expiry (max 72 h).'], ['lock', 'Contact on your terms', 'Organizations see counts only, until you respond “I’m available”. Then only they see your first name and chosen contact.']].map(([i, t, d]) => `<div class="card card-lg stack gap-8"><span class="pin" style="background:var(--sage-50);color:var(--brand-700);width:44px;height:44px">${Ic(i, 22)}</span><h2 class="h3">${t}</h2><p class="small muted" style="margin:0">${d}</p></div>`).join('')}</div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-12"><h2 class="h3">Open requests near you ${W.sample()}</h2>
      ${[['Flood relief: sandbag team', 'Dhaka Food Relief (Sample)', 'Riverside, ~5 km', 'High', '8 needed · 3 available', 'Voluntary'], ['Blood donor coordination desk', 'Community Health Circle (Sample)', 'Harbour, ~5 km', 'Medium', '2 needed · 1 available', 'Stipend']].map(([t, o, a, u, n, c]) => `<div class="card card-pad stack gap-8"><div class="row wrap between gap-8"><strong>${t}</strong>${W.badge('Urgency: ' + u, u === 'High' ? 'rose' : 'amber', 'siren')}</div><span class="caption">${o} · ${a} · expires in 20 h</span><div class="row wrap gap-8">${W.badge(n, 'grey', 'users')}${W.comp(c)}${W.badge('First aid', 'grey')}</div><div class="row gap-8 mt-4"><button class="btn btn--primary btn--sm" data-action="toast" data-msg="Concept: you’d be marked available and the organization notified">I’m available</button><button class="btn btn--ghost btn--sm" data-action="toast" data-msg="Concept: request dismissed">Not this time</button><button class="btn btn--ghost btn--sm" data-action="toast" data-msg="Concept: report sent to moderators">${Ic('flag', 14)}Report</button></div></div>`).join('')}</div>
    <div class="stack gap-12"><div class="map-wrap" style="height:320px">${W.mapSvg({ points: [], areas: true, clusters: false })}</div><p class="caption" style="margin:0">Areas are shown as ~5 km circles with counts only. No individual volunteer locations are ever displayed.</p>
      <div class="card card-pad stack gap-12"><h2 class="h4">Your availability (concept)</h2>
        <div class="row between"><span class="small">Receive urgent requests</span><button class="switch" role="switch" aria-checked="false" data-action="switch" aria-label="Receive urgent requests"></button></div>
        <div class="field"><label class="label" for="ea">Approximate area</label><select id="ea" class="select"><option>Old Town (~5 km)</option><option>Harbour (~5 km)</option></select></div>
        <div class="field"><span class="label">Skills I can offer</span><div class="chips">${['First aid', 'Driving', 'Logistics', 'Translation'].map((s) => `<button class="chip" aria-pressed="false" data-action="toggle">${s}</button>`).join('')}</div></div>
        <span class="caption">${Ic('lock', 12)} Blood group and phone stay private unless you share them for a specific request.</span></div></div>
  </div>
</div></section>`) })
