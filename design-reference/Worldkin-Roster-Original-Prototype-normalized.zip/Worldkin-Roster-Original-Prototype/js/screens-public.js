W.routes = W.routes || {}
W.def = (path, spec) => { W.routes[path] = spec }
const Ic = (n, s, c) => W.icon(n, s, c)

/* A01 Home */
W.def('/home', { code: 'A01', group: 'Public website', title: 'Homepage', render: () => W.publicPage('#/home', `
<section class="hero"><div class="container"><div class="hero-panel">
  <div class="hero-copy">
    <span class="eyebrow">Volunteering · internships · community programmes</span>
    <h1 class="display">Everyone is kin.</h1>
    <p class="lead">Find meaningful opportunities with verified organizations, take part, and build a record of experience the organization itself confirms.</p>
    <form class="search-bar" data-action="hero-search" role="search">
      <div class="input-wrap" style="flex:1.4">${Ic('search')}<label class="sr-only" for="hs">What do you want to do?</label><input id="hs" class="input" placeholder="Teaching, food relief, climate…"></div>
      <div class="divider"></div>
      <div class="input-wrap" style="flex:1">${Ic('map-pin')}<label class="sr-only" for="hl">Where?</label><input id="hl" class="input" placeholder="City or online"></div>
      <button class="btn btn--primary">Find opportunities</button>
    </form>
    <div class="row wrap gap-12"><a href="#/register" class="btn btn--light">${Ic('user', 18)}Join as a volunteer</a><a href="#/register?role=org" class="btn btn--ghost" style="color:#fff;border:1px solid rgba(255,255,255,.35)">${Ic('building', 18)}Register an organization</a></div>
  </div>
  <div class="hero-media">${W.photo('hero', 'Volunteers sorting donations together', '', 'position:absolute;inset:0')}
    <div class="hero-float" style="left:-28px;bottom:48px"><div class="row gap-12">${W.avatar('DF', 40)}<div class="stack"><span class="small" style="font-weight:600">Weekend food parcel packing</span><span class="caption">6 seats left · Sat 28 Nov</span></div></div></div>
    <div class="hero-float" style="right:24px;top:28px"><div class="row gap-8"><span class="verified">${Ic('shield-check', 16)}Verified organization</span></div></div>
  </div></div></div></section>

<section class="section--tight"><div class="container">
  <div class="row between wrap gap-8 mb-16"><h2 class="h3">Impact so far</h2>${W.sample('Sample figures — live values come from verified records')}</div>
  <div class="grid g-4 kpis">${W.kpi('Volunteers', '20', 'users', 'registered', false)}${W.kpi('Verified organizations', '4', 'shield-check', 'reviewed before publishing', false)}${W.kpi('Upcoming events', '6', 'calendar', 'next 60 days', false)}${W.kpi('Verified hours', '1,240', 'clock', 'confirmed by organizations', false)}</div>
</div></section>

<section class="section"><div class="container">
  <div class="section-head"><div><span class="eyebrow">Why Worldkin</span><h2 class="h2 mt-8">A connected journey, not just a listings board</h2></div></div>
  <div class="grid g-3">
    ${[['shield-check', 'Verified organizations', 'Every organization is reviewed before it can publish, and its trust record is public.'], ['users', 'Fair, capacity-safe selection', 'Seats can never be overbooked; waitlists are first-come and transparent.'], ['award', 'Experience you can prove', 'Hours are confirmed by organization staff — never self-reported — and collect in your passport.']]
    .map(([i, t, d]) => `<div class="card card-lg stack gap-12"><span class="pin" style="background:var(--sage-50);color:var(--brand-700);width:44px;height:44px">${Ic(i, 22)}</span><h3 class="h3">${t}</h3><p class="muted small" style="margin:0">${d}</p></div>`).join('')}
  </div></div></section>

<section class="section section--sage"><div class="container">
  <div class="section-head"><div><span class="eyebrow">How it works</span><h2 class="h2 mt-8">From first search to verified experience</h2></div></div>
  <ol class="grid g-3" style="list-style:none;padding:0;margin:0">
    ${[['Discover', 'Search by cause, place, skill and compensation — paid, stipend and voluntary roles are always labelled.'], ['Apply or join', 'Join open shifts instantly, or apply where the organization selects volunteers.'], ['Get selected', 'Selected applicants receive an offer to accept within 72 hours.'], ['Participate', 'Your agenda and calendar keep every shift in one place.'], ['Get verified', 'Organization staff confirm attendance and hours.'], ['Build your passport', 'Verified experience and certificates collect in one profile.']]
    .map(([t, d], i) => `<li class="card card-pad row gap-16" style="align-items:flex-start"><span class="stat-num" style="font-size:22px;color:var(--brand-700);min-width:28px">${String(i + 1).padStart(2, '0')}</span><div><h3 class="h4">${t}</h3><p class="small muted" style="margin:4px 0 0">${d}</p></div></li>`).join('')}
  </ol></div></section>

<section class="section"><div class="container">
  <div class="section-head"><div><span class="eyebrow">Featured</span><h2 class="h2 mt-8">Opportunities near you</h2><p class="muted">Sample listings from verified organizations.</p></div><a href="#/discover" class="btn btn--secondary">View all ${Ic('chevron-right', 16)}</a></div>
  <div class="grid g-3">${W.OPPS.slice(0, 3).map(W.oppCard).join('')}</div>
</div></section>

<section class="section--tight"><div class="container grid g-main-aside" style="align-items:start">
  <div><div class="section-head"><h2 class="h2">Upcoming events</h2><a href="#/events" class="link">All events</a></div><div class="stack gap-12">${W.EVENTS.slice(0, 4).map(W.eventRow).join('')}</div></div>
  <div><div class="section-head"><h2 class="h2">Verified organizations</h2></div><div class="stack gap-12">${W.ORGS.filter((o) => o.verified).slice(0, 3).map(W.orgCard).join('')}</div></div>
</div></section>

<section class="section"><div class="container">
  <div class="section-head"><div><span class="eyebrow">Stories &amp; media</span><h2 class="h2 mt-8">What our community is doing</h2></div><a href="#/media" class="link">Open gallery</a></div>
  <div class="grid g-main-aside" style="align-items:stretch">
    <a href="#/video" class="tile" style="aspect-ratio:16/9;min-height:280px">${W.photo('food', 'Community kitchen video', '', 'position:absolute;inset:0')}<span style="position:absolute;inset:0;display:grid;place-items:center"><span class="play">${Ic('play', 26)}</span></span><span class="duration">3:42</span><span class="cap"><span class="eyebrow" style="color:#b8e2d0">Featured video</span><span class="h3" style="display:block;color:#fff">A Saturday at the community kitchen</span></span></a>
    <div class="stack gap-16">${W.MEDIA.filter((m) => m.type !== 'video').slice(0, 2).map((m) => `<a href="#/media?item=${m.id}" class="tile" style="aspect-ratio:16/9">${W.photo(m.photo, m.title, '', 'position:absolute;inset:0')}<span class="cap"><span class="small" style="font-weight:600">${m.title}</span></span></a>`).join('')}</div>
  </div></div></section>

<section class="section--tight"><div class="container">
  <div class="row between wrap gap-8 mb-16"><h2 class="h3">Collaboration partners</h2>${W.sample('Placeholder partner slots — no real partners yet')}</div>
  <div class="marquee"><div class="marquee-track">${[...Array(2)].map(() => ['Partner slot 1', 'Partner slot 2', 'Partner slot 3', 'Partner slot 4', 'Partner slot 5', 'Partner slot 6'].map((p) => `<span class="partner">${Ic('building', 18)}${p}</span>`).join('')).join('')}</div></div>
</div></section>

<section class="section"><div class="container grid g-2">
  <div class="card card-lg stack gap-12" style="background:#fbeee4;border-color:#f1d9c7"><span class="concept-tag">${Ic('sparkle', 12)}Concept · no payments in this release</span><h2 class="h2">Support a cause</h2>
    <p class="muted" style="margin:0">Organizations will be able to link to their own official donation pages. Worldkin will never take card details or show unverified totals.</p>
    <div class="row gap-8 mt-8"><a href="#/organizations" class="btn btn--accent">${Ic('heart', 18)}Find organizations to support</a></div></div>
  <div class="card card-lg stack gap-12" style="background:var(--forest-900);color:#fff;border:0"><span class="concept-tag" style="background:rgba(255,255,255,.1);color:#f3c7a8">${Ic('sparkle', 12)}Future module</span><h2 class="h2" style="color:#fff">Emergency volunteer network</h2>
    <p style="margin:0;color:#cfe1da">Opt in to be alerted when verified organizations need nearby help. Not an emergency service — always call local emergency numbers first.</p>
    <div class="row gap-8 mt-8"><a href="#/emergency" class="btn btn--light">Learn how it would work</a></div></div>
</div></section>`) })

/* A02 Discover */
W.def('/discover', { code: 'A02', group: 'Public website', title: 'Discover opportunities', render: () => W.publicPage('#/discover', `
<section class="section--tight"><div class="container stack gap-24">
  <div>${W.crumbs([['Home', '#/home'], ['Discover']])}<h1 class="h1">Discover opportunities</h1><p class="lead" style="margin:8px 0 0">Volunteer roles, internships, fellowships and paid part-time work from verified organizations.</p></div>
  <div class="card card-pad stack gap-16">
    <div class="row wrap gap-12">
      <div class="input-wrap" style="flex:2;min-width:220px">${Ic('search')}<label class="sr-only" for="dq">Search</label><input id="dq" class="input" placeholder="Search title, skill or organization" data-action="filter-text"></div>
      <div style="flex:1;min-width:150px"><label class="sr-only" for="dl">Location</label><select id="dl" class="select"><option>Any location</option><option>Dhaka</option><option>Khulna</option><option>Sylhet</option><option>Online</option></select></div>
      <div style="flex:1;min-width:150px"><label class="sr-only" for="dd">Date</label><select id="dd" class="select"><option>Any date</option><option>This week</option><option>This month</option></select></div>
      <div style="flex:1;min-width:150px"><label class="sr-only" for="ds">Sort</label><select id="ds" class="select"><option>Soonest first</option><option>Most seats left</option><option>Newest</option><option>Closing soon</option></select></div>
    </div>
    <div class="row wrap gap-16 between">
      <div class="chips" role="group" aria-label="Opportunity type">${['All', 'Volunteer', 'Internship', 'Fellowship', 'Part-time', 'Event'].map((c, i) => `<button class="chip" data-action="chip" data-filter="kind" data-value="${c}" aria-pressed="${i === 0}">${c}</button>`).join('')}</div>
      <div class="chips" role="group" aria-label="Compensation">${['Any pay', 'Voluntary', 'Stipend', 'Paid'].map((c, i) => `<button class="chip" data-action="chip" data-filter="comp" data-value="${c}" aria-pressed="${i === 0}">${c}</button>`).join('')}</div>
    </div>
    <div class="row wrap gap-16 between"><label class="checkbox"><input type="checkbox" data-action="only-open"> Only with open seats</label>
      <div class="seg" role="group" aria-label="View"><button aria-pressed="true">${Ic('grid', 16)}Grid</button><a href="#/map" class="btn btn--ghost btn--sm" style="min-height:30px">${Ic('map', 16)}Map view</a></div></div>
  </div>
  <div class="row between"><span class="small muted" data-count>${W.OPPS.length} results</span>${W.sample()}</div>
  <div class="grid g-3" data-results>${W.OPPS.map(W.oppCard).join('')}</div>
  <div class="row gap-8" style="justify-content:center"><button class="btn btn--secondary">Load more</button></div>
</div></section>`), mount: (root) => {
  const st = { kind: 'All', comp: 'Any pay', text: '', open: false }
  const apply = () => {
    const list = W.OPPS.filter((o) => (st.kind === 'All' || o.kind === st.kind) && (st.comp === 'Any pay' || o.comp === st.comp) && (!st.open || o.confirmed < o.capacity) && (!st.text || (o.title + o.cause + W.org(o.org).name + o.skills.join()).toLowerCase().includes(st.text)))
    root.querySelector('[data-results]').innerHTML = list.length ? list.map(W.oppCard).join('') : `<div style="grid-column:1/-1" class="card">${W.empty('search', 'No opportunities match these filters', 'Try removing a filter or searching a nearby city.', '<button class="btn btn--secondary" data-action="reset">Clear filters</button>')}</div>`
    root.querySelector('[data-count]').textContent = list.length + (list.length === 1 ? ' result' : ' results')
  }
  root.addEventListener('click', (e) => {
    const c = e.target.closest('[data-action="chip"]'); if (c) { root.querySelectorAll(`[data-filter="${c.dataset.filter}"]`).forEach((b) => b.setAttribute('aria-pressed', b === c)); st[c.dataset.filter] = c.dataset.value; apply() }
    if (e.target.closest('[data-action="reset"]')) { W.go('#/discover') }
  })
  root.querySelector('[data-action="filter-text"]').addEventListener('input', (e) => { st.text = e.target.value.toLowerCase(); apply() })
  root.querySelector('[data-action="only-open"]').addEventListener('change', (e) => { st.open = e.target.checked; apply() })
} })

/* A03 Opportunity details */
W.def('/opportunity', { code: 'A03', group: 'Public website', title: 'Opportunity details', render: (p) => {
  const o = W.opp(p.id) || W.OPPS[2], org = W.org(o.org), ckey = { dfr: 'A', gdc: 'B', cle: 'C', chc: 'E' }[o.org] || 'D'
  return W.publicPage('#/discover', `<section class="section--tight"><div class="container stack gap-24">
  ${W.crumbs([['Discover', '#/discover'], [o.cause, '#/discover'], [o.title]])}
  <div class="photo" style="height:340px;border-radius:var(--r-lg)">${W.photo(o.photo, o.title, '', 'position:absolute;inset:0')}</div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-24">
      <div class="stack gap-12"><div class="row wrap gap-8">${W.badge(o.kind, 'brand')}${W.comp(o.comp)}${W.badge(o.select, o.select === 'Application' ? 'amber' : 'green')}${o.cert ? W.badge('Certificate on verified completion', 'grey', 'award') : ''}</div>
        <h1 class="h1">${o.title}</h1>
        <a href="#/org-profile?id=${org.id}" class="org-line" style="text-decoration:none">${W.avatar(org.short, 32)}<strong>${org.name}</strong>${W.verifiedMark(org.verified)}</a>
        <div class="meta" style="font-size:15px"><span>${Ic('map-pin')}${o.city}</span><span>${Ic('globe')}${o.mode}</span><span>${Ic('calendar')}${o.date}</span><span>${Ic('clock')}${o.time}</span></div></div>
      <div class="card card-lg stack gap-12"><h2 class="h3">About this opportunity</h2><p class="muted" style="margin:0">Join a small team supporting ${o.cause.toLowerCase()} work in ${o.city}. You will be briefed on arrival, work alongside trained staff and finish with a short debrief. <em>Sample description.</em></p>
        <h3 class="h4 mt-8">Responsibilities</h3><ul class="small muted" style="margin:0;padding-left:18px"><li>Prepare materials and set up the space</li><li>Work with participants following the coordinator’s plan</li><li>Record what was completed for the debrief</li></ul>
        <h3 class="h4 mt-8">Requirements &amp; skills</h3><div class="row wrap gap-8">${o.skills.map((s) => W.badge(s, 'grey')).join('')}${W.badge('18+', 'grey')}</div>
        ${o.comp !== 'Voluntary' ? `<div class="alert alert--info mt-8">${Ic('info', 18)}<span><strong>${o.comp}:</strong> ${o.compDetail}. Paid and stipend terms are set by the organization and shown before you apply.</span></div>` : `<div class="alert alert--success mt-8">${Ic('heart', 18)}<span>This is an unpaid, voluntary role.</span></div>`}</div>
      <div class="card card-lg stack gap-12"><h2 class="h3">What happens next</h2>
        <ol class="stack gap-8 small" style="margin:0;padding-left:20px">${(o.select === 'Application' ? ['Apply with your profile (one active application per opportunity).', 'The organization reviews applicants.', 'If selected, accept or decline the offer within 72 hours.', 'Your seat is booked safely — if it filled meanwhile, you join the waitlist in order.', 'After the shift, staff confirm your attendance and hours.', 'Verified hours appear on your certificate and passport.'] : ['Join any shift with free seats — no application needed.', 'If a shift is full, join the first-come waitlist.', 'After the shift, staff confirm attendance and hours.', 'Verified hours appear on your passport.']).map((s) => `<li>${s}</li>`).join('')}</ol></div>
    </div>
    <aside class="stack gap-16" style="position:sticky;top:120px">
      <div class="card card-lg stack gap-16"><div class="row between"><span class="h4">Next shift</span>${o.deadline ? W.badge(o.deadline, 'terra', 'clock') : ''}</div>
        <div class="small"><strong>${o.date}</strong> · ${o.time}</div>${W.meter(o.confirmed, o.capacity, o.waitlist)}
        ${o.select === 'Application' ? `<a href="#/login/volunteer?next=apply" class="btn btn--primary btn--lg btn--block">Apply now</a>` : o.confirmed >= o.capacity ? `<a href="#/login/volunteer" class="btn btn--secondary btn--lg btn--block">Join waitlist</a>` : `<a href="#/login/volunteer" class="btn btn--primary btn--lg btn--block">Join this shift</a>`}
        <p class="caption" style="margin:0;text-align:center">You’ll be asked to sign in. Nothing is booked until you confirm.</p></div>
      ${W.contactPanel(ckey, { compact: true })}
      <a href="#/org-profile?id=${org.id}" class="btn btn--secondary">${Ic('building', 18)}View organization profile</a>
    </aside>
  </div>
  <div><div class="section-head"><h2 class="h2">Related opportunities</h2></div><div class="grid g-3">${W.OPPS.filter((x) => x.id !== o.id).slice(0, 3).map(W.oppCard).join('')}</div></div>
</div></section>`)
} })

/* A04 Organizations directory */
W.def('/organizations', { code: 'A04', group: 'Public website', title: 'Organizations directory', render: () => W.publicPage('#/organizations', `
<section class="section--tight"><div class="container stack gap-24">
  <div>${W.crumbs([['Home', '#/home'], ['Organizations']])}<h1 class="h1">Verified organizations</h1><p class="lead" style="margin:8px 0 0">NGOs, charities, community groups and university clubs reviewed by Worldkin before they can publish.</p></div>
  <div class="card card-pad row wrap gap-12"><div class="input-wrap" style="flex:2;min-width:220px">${Ic('search')}<label class="sr-only" for="os">Search</label><input id="os" class="input" placeholder="Search organizations"></div>
    <select class="select" style="flex:1;min-width:160px" aria-label="Type"><option>All types</option><option>NGO</option><option>Charity</option><option>University club</option><option>Community group</option></select>
    <select class="select" style="flex:1;min-width:160px" aria-label="Cause"><option>All causes</option><option>Food security</option><option>Climate</option><option>Education</option><option>Health</option></select></div>
  <div class="row between"><span class="small muted">${W.ORGS.filter((o) => o.verified).length} verified organizations</span>${W.sample()}</div>
  <div class="grid g-2">${W.ORGS.filter((o) => o.verified).map(W.orgCard).join('')}</div>
  <div class="alert alert--info">${Ic('info', 18)}<span>Organizations awaiting verification are not listed publicly and cannot publish opportunities.</span></div>
</div></section>`) })

/* A05 Organization public profile (+ contact states A–E) */
W.def('/org-profile', { code: 'A05', group: 'Public website', title: 'Organization trust profile', render: (p) => {
  const o = W.org(p.id) || W.ORGS[0], ck = p.contact || ({ dfr: 'A', gdc: 'B', cle: 'C', chc: 'E' }[o.id] || 'D')
  return W.publicPage('#/organizations', `<section class="section--tight"><div class="container stack gap-24">
  ${W.crumbs([['Organizations', '#/organizations'], [o.name]])}
  <div class="photo" style="height:220px;border-radius:var(--r-lg)">${W.photo(o.photo, o.name + ' cover', '', 'position:absolute;inset:0')}</div>
  <div class="row wrap gap-16" style="margin-top:-56px;padding:0 24px;align-items:flex-end;position:relative">
    <span style="border:4px solid var(--surface);border-radius:16px">${W.avatar(o.short, 96)}</span>
    <div class="stack gap-4" style="flex:1;min-width:240px"><h1 class="h1">${o.name}</h1><div class="row wrap gap-8"><span class="caption">${o.type} · ${o.cause} · ${o.city}</span>${W.verifiedMark(o.verified)}</div></div>
  </div>
  <div class="card card-pad row wrap gap-8" style="background:#fff8ef;border-color:#f1dfc6"><span class="small" style="font-weight:600">Prototype · contact data state:</span>
    ${Object.entries(W.CONTACT_STATES).map(([k, v]) => `<a class="chip" aria-pressed="${k === ck}" href="#/org-profile?id=${o.id}&contact=${k}">${v.label}</a>`).join('')}</div>
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-24">
      <div class="card card-lg stack gap-8"><h2 class="h3">About</h2><p class="muted" style="margin:0">${o.about}</p><span class="caption">${Ic('info', 12)} Written by the organization.</span></div>
      <div><div class="section-head"><h2 class="h3">Upcoming opportunities</h2></div><div class="grid g-2">${W.OPPS.filter((x) => x.org === o.id).slice(0, 4).map(W.oppCard).join('') || W.empty('briefcase', 'No open opportunities right now')}</div></div>
      <div><div class="section-head"><h2 class="h3">Past activities</h2></div><div class="stack gap-12">${W.EVENTS.filter((e) => e.status === 'held').map(W.eventRow).join('')}</div></div>
      <div class="card card-lg stack gap-12"><div class="row between"><h2 class="h3">Reviews from verified participants</h2>${W.sample()}</div>
        ${o.rating ? `<div class="row gap-12"><span class="stat-num">${o.rating}</span><span class="small muted">from ${o.reviews} volunteers whose attendance was verified</span></div>
        <blockquote class="small" style="margin:0;padding:12px 16px;border-left:3px solid var(--sage-200);background:var(--sage-50);border-radius:8px">“Well organized and welcoming. The coordinator explained everything.” <span class="caption">— Nadia · Weekend food parcel packing</span></blockquote>` : W.empty('star', 'No reviews yet', 'Only volunteers whose participation was verified can review.')}</div>
    </div>
    <aside class="stack gap-16">
      <div class="card card-pad stack gap-12"><h2 class="h4">Trust record</h2>
        <ul class="stack gap-8 small" style="list-style:none;margin:0;padding:0">
          <li class="row gap-8">${Ic('shield-check', 18, 'verified')}<span>${o.verified ? 'Verified by Worldkin on 25 Nov 2026' : 'Verification pending'}</span></li>
          <li class="row gap-8">${Ic('calendar', 18)}<span>${o.events} public events held in the last 6 months</span></li>
          <li class="row gap-8">${Ic('users', 18)}<span>On Worldkin since ${o.since}</span></li></ul>
        <p class="caption" style="margin:0">Verification confirms identity and documents. It does not make private details public.</p></div>
      ${W.contactPanel(ck)}
      <div class="card card-pad stack gap-8"><h2 class="h4">Concern about this organization?</h2><p class="small muted" style="margin:0">Reports go privately to Worldkin moderators.</p><a href="#/login/volunteer" class="link small">Report privately</a></div>
    </aside></div>
</div></section>`)
} })

/* A06 Events */
W.def('/events', { code: 'A06', group: 'Public website', title: 'Events', render: () => W.publicPage('#/events', `
<section class="section--tight"><div class="container stack gap-24">
  <div>${W.crumbs([['Home', '#/home'], ['Events']])}<h1 class="h1">Events</h1><p class="lead" style="margin:8px 0 0">Shifts and activities from verified organizations. Open an event to join or apply.</p></div>
  <div class="card card-pad row wrap gap-12"><select class="select" style="flex:1;min-width:150px" aria-label="Cause"><option>All causes</option><option>Climate</option><option>Food security</option></select><select class="select" style="flex:1;min-width:150px" aria-label="Mode"><option>Any mode</option><option>On-site</option><option>Online</option><option>Hybrid</option></select><select class="select" style="flex:1;min-width:150px" aria-label="Compensation"><option>Any compensation</option><option>Voluntary</option><option>Stipend</option><option>Paid</option></select></div>
  <section aria-labelledby="now"><h2 id="now" class="h3 row gap-8 mb-16"><span class="dot-unread" style="background:var(--natural-500)"></span>Happening now</h2><div class="stack gap-12">${W.EVENTS.filter((e) => e.status === 'now').map(W.eventRow).join('')}</div></section>
  <section aria-labelledby="up"><h2 id="up" class="h3 mb-16">Upcoming <span class="small muted">· next 60 days</span></h2><div class="stack gap-12">${W.EVENTS.filter((e) => e.status === 'upcoming').map(W.eventRow).join('')}</div></section>
  <section aria-labelledby="held"><h2 id="held" class="h3">Recently held</h2><p class="small muted">Events that took place and were not cancelled. Attendance is verified separately by each organization.</p><div class="stack gap-12">${W.EVENTS.filter((e) => e.status === 'held').map(W.eventRow).join('')}</div></section>
</div></section>`) })

/* A07 Event details */
W.def('/event', { code: 'A07', group: 'Public website', title: 'Event details', render: (p) => {
  const e = W.EVENTS.find((x) => x.id === p.id) || W.EVENTS[1], o = W.opp(e.opp), org = W.org(o.org)
  return W.publicPage('#/events', `<section class="section--tight"><div class="container stack gap-24">
  ${W.crumbs([['Events', '#/events'], [e.title]])}
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-16"><h1 class="h1">${e.title}</h1><div class="meta" style="font-size:15px"><span>${Ic('calendar')}${e.when}</span><span>${Ic('map-pin')}${o.city}</span><span>${Ic('globe')}${o.mode}</span></div>
      <div class="photo" style="height:300px;border-radius:var(--r-lg)">${W.photo(o.photo, e.title, '', 'position:absolute;inset:0')}</div>
      <div class="card card-lg stack gap-8"><div class="row wrap gap-8">${W.comp(o.comp)}${W.badge(o.cause, 'grey')}</div><h2 class="h3 mt-8">${o.title}</h2><p class="muted" style="margin:0">Part of “${o.title}”. Bring water and comfortable shoes; materials are provided. <em>Sample.</em></p><a href="#/opportunity?id=${o.id}" class="link small">Full opportunity details</a></div>
      <div><h2 class="h3 mb-16">More from this organizer</h2><div class="stack gap-12">${W.EVENTS.filter((x) => x.id !== e.id && W.opp(x.opp).org === o.org).slice(0, 3).map(W.eventRow).join('')}</div></div>
    </div>
    <aside class="stack gap-16"><div class="card card-lg stack gap-12">${e.status === 'held' ? `<p class="small" style="margin:0">This event has ended. Hours for those who attended are verified by the organization.</p>` : `${W.meter(o.confirmed, o.capacity, o.waitlist)}<p class="small muted" style="margin:0">${o.select === 'Application' ? 'Selection by application — apply on the opportunity page.' : 'Open sign-up — join while seats are free, otherwise join the waitlist.'}</p>
      <a href="#/opportunity?id=${o.id}" class="btn btn--primary btn--block">${o.select === 'Application' ? 'Apply on the opportunity page' : 'Join on the opportunity page'}</a><button class="btn btn--ghost" data-action="toast" data-msg="Calendar file prepared (prototype)">${Ic('calendar', 18)}Add to calendar</button>`}</div>
      <a href="#/org-profile?id=${org.id}" class="card card-pad row gap-12" style="text-decoration:none">${W.avatar(org.short, 44)}<div class="stack"><span class="caption">Organizer</span><strong class="small">${org.name}</strong>${W.verifiedMark(org.verified)}</div></a></aside>
  </div></div></section>`)
} })

/* A08 Media gallery */
W.def('/media', { code: 'A08', group: 'Media & community', title: 'Stories & media gallery', render: () => W.publicPage('#/media', `
<section class="section--tight"><div class="container stack gap-24">
  <div>${W.crumbs([['Home', '#/home'], ['Stories & media']])}<div class="row wrap between gap-12"><h1 class="h1">Stories &amp; media</h1>${W.concept('Requires approved media module (wk08)')}</div>
    <p class="lead" style="margin:8px 0 0">Photos, videos and stories published by verified organizations after moderation.</p></div>
  <div class="row wrap between gap-12"><div class="chips" role="group" aria-label="Media type">${['All', 'Photos', 'Videos', 'Stories'].map((c, i) => `<button class="chip" data-action="chip-media" data-value="${c}" aria-pressed="${i === 0}">${c}</button>`).join('')}</div>
    <div class="row gap-8"><select class="select" aria-label="Organization"><option>All organizations</option>${W.ORGS.filter((o) => o.verified).map((o) => `<option>${o.name}</option>`).join('')}</select><select class="select" aria-label="Cause"><option>All causes</option><option>Climate</option><option>Education</option></select></div></div>
  <div class="masonry" data-gallery>${W.MEDIA.map((m) => `<button class="tile" data-type="${m.type}" data-action="lightbox" data-id="${m.id}" style="height:${m.h}px">${W.photo(m.photo, m.title, '', 'position:absolute;inset:0')}${m.type === 'video' ? `<span style="position:absolute;inset:0;display:grid;place-items:center"><span class="play" style="width:52px;height:52px">${Ic('play', 22)}</span></span><span class="duration">${m.dur}</span>` : ''}<span class="cap"><span class="caption" style="color:#cfe8de">${m.type.toUpperCase()} · ${W.org(m.org).name}</span><span class="small" style="display:block;font-weight:600">${m.title}</span></span></button>`).join('')}</div>
  <p class="caption">${Ic('lock', 12)} Only media approved by a moderator appears here. People shown have given consent (recorded by the uploading organization).</p>
</div></section>`), mount: (root) => {
  root.addEventListener('click', (e) => {
    const c = e.target.closest('[data-action="chip-media"]')
    if (c) { root.querySelectorAll('[data-action="chip-media"]').forEach((b) => b.setAttribute('aria-pressed', b === c)); const map = { Photos: 'photo', Videos: 'video', Stories: 'story' }; root.querySelectorAll('[data-gallery] .tile').forEach((t) => { t.hidden = c.dataset.value !== 'All' && t.dataset.type !== map[c.dataset.value] }) }
    const t = e.target.closest('[data-action="lightbox"]')
    if (t) { const m = W.MEDIA.find((x) => x.id === t.dataset.id); if (m.type === 'video') return W.go('#/video'); W.modal({ title: m.title, body: `<div class="photo" style="height:280px;border-radius:12px">${W.photo(m.photo, m.title, '', 'position:absolute;inset:0')}</div><p class="small" style="margin:12px 0 0">${W.org(m.org).name} · ${m.date} · ${m.cause}</p><p class="caption">Photo published after moderation · sample.</p>`, confirm: 'View organization', onConfirm: () => W.go('#/org-profile?id=' + m.org) }) }
  })
} })

/* A09 Video experience */
W.def('/video', { code: 'A09', group: 'Media & community', title: 'Video experience', render: () => W.publicPage('#/media', `
<section class="section--tight"><div class="container stack gap-24">
  ${W.crumbs([['Stories & media', '#/media'], ['A Saturday at the community kitchen']])}
  <div class="grid g-main-aside" style="align-items:start">
    <div class="stack gap-16"><div class="player">${W.photo('food', 'Video still', '', 'position:absolute;inset:0;opacity:.75')}<span style="position:absolute;inset:0;display:grid;place-items:center"><span class="play">${Ic('play', 28)}</span></span>
      <div class="player-bar">${Ic('play', 18)}<span class="caption" style="color:#fff">1:12 / 3:42</span><span class="track"><span></span></span>${Ic('sliders', 18)}</div></div>
      <div class="row wrap between gap-12"><div><h1 class="h2">A Saturday at the community kitchen</h1><span class="caption">Dhaka Food Relief Network (Sample) · 21 Nov 2026 · Food security</span></div>${W.concept('Player placeholder · hosting not implemented')}</div>
      <p class="muted" style="margin:0">Volunteers prepare 300 meals in four hours. Videos would be embedded from the organization’s own channel (e.g. YouTube) after moderation — Worldkin would not host video files in the first release.</p></div>
    <aside class="stack gap-12"><h2 class="h4">Related videos</h2>${W.MEDIA.filter((m) => m.type === 'video').concat(W.MEDIA.slice(0, 2)).map((m) => `<a href="#/video" class="row gap-12" style="text-decoration:none"><span class="tile" style="width:140px;aspect-ratio:16/9;flex-shrink:0">${W.photo(m.photo, m.title, '', 'position:absolute;inset:0')}<span class="duration">${m.dur || '2:10'}</span></span><span class="stack"><strong class="small">${m.title}</strong><span class="caption">${W.org(m.org).name}</span></span></a>`).join('')}</aside>
  </div></div></section>`) })

/* A12 About / contact / legal */
W.def('/about', { code: 'A12', group: 'Public website', title: 'About, contact & legal', render: () => W.publicPage('#/about', `
<section class="section--tight"><div class="container stack gap-32" style="max-width:880px">
  <div>${W.crumbs([['Home', '#/home'], ['About']])}<h1 class="h1">About Worldkin Roster</h1><p class="lead">Worldkin Roster connects volunteers and young professionals with verified organizations — and turns real participation into experience the organization confirms.</p></div>
  <div class="grid g-2"><div class="card card-lg"><h2 class="h3">Mission</h2><p class="muted small" style="margin:8px 0 0">Make it simple and safe to help, and make that help count.</p></div><div class="card card-lg"><h2 class="h3">Vision</h2><p class="muted small" style="margin:8px 0 0">A world where every contribution is recognised — everyone is kin.</p></div></div>
  <div id="verification" class="card card-lg stack gap-8"><h2 class="h3">How verification works</h2><p class="muted small" style="margin:0">Organizations submit details and documents privately. A Verification Admin reviews them before the organization can publish. Documents are never public.</p></div>
  <div id="contact" class="card card-lg stack gap-12"><h2 class="h3">Contact</h2><div class="alert alert--warning">${Ic('info', 18)}<span>Official contact email and social links will be added by the Worldkin team. No contact details are invented in this prototype.</span></div>
    <form class="stack gap-12" data-action="fake-submit"><div class="grid g-2"><div class="field"><label class="label" for="cn">Name</label><input id="cn" class="input"></div><div class="field"><label class="label" for="ce">Email</label><input id="ce" type="email" class="input"></div></div><div class="field"><label class="label" for="cm">Message</label><textarea id="cm" class="textarea"></textarea></div><button class="btn btn--primary" style="align-self:flex-start">Send message</button><span class="caption">Prototype — nothing is sent.</span></form></div>
  <div id="faq" class="stack gap-8"><h2 class="h3">FAQ</h2>${[['Is Worldkin free for volunteers?', 'Yes. Volunteers never pay to apply.'], ['How are hours verified?', 'Only organization staff can record attendance and hours; volunteers cannot edit their own record.'], ['Are paid roles labelled?', 'Every opportunity shows Voluntary, Stipend or Paid, with details, before you apply.']].map(([q, a]) => `<details class="card card-pad"><summary class="h4" style="cursor:pointer">${q}</summary><p class="small muted" style="margin:8px 0 0">${a}</p></details>`).join('')}</div>
  <div id="privacy" class="card card-lg"><h2 class="h3">Privacy policy</h2><p class="small muted">Placeholder — the final policy text must be provided by the Worldkin team. Key principles shown in the product: private documents are never public, contact details are opt-in, applicant contact data is never shown to organizations.</p></div>
  <div id="terms" class="card card-lg"><h2 class="h3">Terms of service</h2><p class="small muted">Placeholder — legal text to be supplied by the owner.</p></div>
</div></section>`) })
