/* Reusable components. Every screen is assembled from these — no page duplicates markup. */
const I = (n, s, c) => W.icon(n, s, c)
W.esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))

/* Photo with graceful fallback: a labelled sample placeholder if the remote image fails. */
W.photo = (key, alt = '', cls = '', style = '') => {
  const id = W.PHOTOS[key] || W.PHOTOS.team
  return `<div class="photo ${cls}" style="${style}"><img src="${W.IMG(id)}" alt="${W.esc(alt)}" loading="lazy"
    onerror="this.parentNode.classList.add('ph');this.parentNode.innerHTML='${I('image', 32).replace(/"/g, '&quot;')}<span class=&quot;ph-label&quot;>Sample image</span>'"></div>`
}

W.logo = (light = false) => `<a href="#/home" class="logo" style="${light ? 'color:#fff' : ''}" aria-label="Worldkin Roster home">
  <span class="logo-mark">${I('users', 18)}</span><span>Worldkin Roster</span></a>`

W.badge = (text, tone = 'grey', icon) => `<span class="badge b-${tone}">${icon ? I(icon, 14) : ''}${W.esc(text)}</span>`
const STATUS = {
  Confirmed: ['green', 'check'], Attended: ['green', 'check-circle'], Accepted: ['green', 'check'], Published: ['green', 'check'], Verified: ['green', 'shield-check'], Present: ['green', 'check'], Resolved: ['green', 'check'], Approved: ['green', 'check'], Active: ['green', 'check'],
  Waitlisted: ['amber', 'clock'], Pending: ['amber', 'clock'], 'Under review': ['amber', 'clock'], 'In review': ['amber', 'clock'], Open: ['amber', 'flag'], 'Needs info': ['amber', 'info'],
  Offer: ['sky', 'briefcase'], 'Offer sent': ['sky', 'briefcase'], Submitted: ['grey', 'file-text'], Draft: ['grey', 'pencil'], Closed: ['grey', 'lock'], Withdrawn: ['grey', 'x'], Scheduled: ['brand', 'calendar'],
  Rejected: ['rose', 'x'], 'Not selected': ['rose', 'x'], Expired: ['rose', 'clock'], 'No-show': ['rose', 'x'], Absent: ['rose', 'x'], Suspended: ['rose', 'lock'], Disputed: ['terra', 'scale'], Hidden: ['grey', 'eye-off'],
}
W.status = (s) => { const [t, i] = STATUS[s] || ['grey', 'info']; return W.badge(s, t, i) }
W.comp = (c) => W.badge(c === 'Voluntary' ? 'Voluntary · unpaid' : c, c === 'Paid' ? 'sky' : c === 'Stipend' ? 'terra' : 'brand', c === 'Voluntary' ? 'heart' : 'briefcase')
W.verifiedMark = (v) => v ? `<span class="verified">${I('shield-check', 15)}Verified</span>` : `<span class="badge b-amber">${I('clock', 14)}Verification pending</span>`
W.sample = (t = 'Sample') => `<span class="sample-tag">${I('info', 12)}${t}</span>`
W.concept = (t = 'Concept · not built yet') => `<span class="concept-tag">${I('sparkle', 12)}${t}</span>`
W.crumbs = (items) => `<nav class="crumbs" aria-label="Breadcrumb">${items.map(([l, h], i) => (i ? I('chevron-right', 14) : '') + (h ? `<a href="${h}">${W.esc(l)}</a>` : `<span aria-current="page">${W.esc(l)}</span>`)).join('')}</nav>`
W.avatar = (txt, size = 40, round = false) => `<span class="avatar ${round ? 'avatar--round' : ''}" style="width:${size}px;height:${size}px;font-size:${Math.round(size / 2.6)}px">${W.esc(txt)}</span>`

W.meter = (confirmed, capacity, waitlist = 0, compact = false) => {
  const pct = Math.min(100, Math.round((confirmed / capacity) * 100)), left = Math.max(capacity - confirmed, 0)
  return `<div class="stack gap-4">
    <div class="meter" role="img" aria-label="${confirmed} of ${capacity} seats confirmed"><span style="width:${pct}%"></span></div>
    <div class="caption">${confirmed} of ${capacity} confirmed · <strong style="color:${left ? 'var(--green-800)' : 'var(--amber-700)'}">${left ? left + ' seats left' : 'Full'}</strong>${waitlist ? ` · ${waitlist} waitlisted` : ''}${compact ? '' : ' · <span title="Available seats = capacity minus confirmed participants. Waitlisted people are not counted as confirmed.">ⓘ</span>'}</div></div>`
}

W.oppCard = (o) => {
  const org = W.org(o.org)
  return `<a href="#/opportunity?id=${o.id}" class="card card--hover opp-card">
    <div class="media">${W.photo(o.photo, o.title, '', 'position:absolute;inset:0')}${W.badge(o.kind, 'brand')}</div>
    <div class="body">
      <div class="org-line">${W.avatar(org.short, 24)}<span>${W.esc(org.name)}</span>${org.verified ? I('shield-check', 15, 'verified-ic') : ''}</div>
      <h3 class="h4" style="font-size:17px;line-height:1.35">${W.esc(o.title)}</h3>
      <div class="meta"><span>${I('map-pin')}${W.esc(o.city)}</span><span>${I('calendar')}${o.date}</span></div>
      <div class="row wrap gap-8 mt-4">${W.comp(o.comp)}${W.badge(o.select, o.select === 'Application' ? 'amber' : 'green')}</div>
      <div class="mt-8">${W.meter(o.confirmed, o.capacity, o.waitlist, true)}</div>
    </div></a>`
}

W.orgCard = (o) => `<a href="#/org-profile?id=${o.id}" class="card card--hover card-pad" style="display:flex;gap:14px;text-decoration:none">
  ${W.avatar(o.short, 56)}
  <div class="stack gap-4" style="min-width:0">
    <div class="h4">${W.esc(o.name)}</div>
    <div class="caption">${o.type} · ${o.cause} · ${o.city}</div>
    <div class="row wrap gap-8 mt-8">${W.verifiedMark(o.verified)}${o.verified ? W.badge(o.opps + ' open opportunities', 'grey') : ''}${o.rating ? W.badge('★ ' + o.rating + ' · ' + o.reviews + ' verified reviews', 'amber') : ''}</div>
  </div></a>`

W.eventRow = (e) => {
  const o = W.opp(e.opp), org = W.org(o.org)
  return `<a href="#/event?id=${e.id}" class="card card--hover card-pad row gap-16" style="text-decoration:none">
    <div class="stack" style="min-width:72px;text-align:center;padding:8px;border-radius:10px;background:${e.status === 'now' ? 'var(--green-50)' : 'var(--sage-50)'}">
      <span class="caption" style="font-weight:600;color:var(--brand-700)">${e.status === 'now' ? 'LIVE NOW' : e.when.split('·')[0]}</span></div>
    <div class="stack gap-4" style="flex:1;min-width:0"><span class="h4">${W.esc(e.title)}</span>
      <span class="caption">${W.esc(org.name)} · ${o.mode === 'Remote' ? 'Online' : W.esc(o.city)} · ${e.when.split('·')[1] || ''}</span></div>
    <span class="desktop-only">${W.comp(o.comp)}</span>${I('chevron-right', 18)}</a>`
}

W.kpi = (label, value, icon, delta = '', sample = true) => `<div class="card kpi"><span class="label">${I(icon, 16)}${label}</span>
  <span class="stat-num">${value}</span><span class="delta">${delta}${sample ? ' · <em>sample</em>' : ''}</span></div>`

W.empty = (icon, title, body = '', action = '') => `<div class="empty"><div class="ico">${I(icon, 28)}</div><div class="h3">${title}</div>
  ${body ? `<p class="muted small" style="max-width:420px;margin:0">${body}</p>` : ''}${action}</div>`

W.bars = (vals, labels, unit = 'h') => {
  const max = Math.max(...vals, 1)
  return `<div class="bars" role="img" aria-label="${labels.map((l, i) => l + ' ' + vals[i] + unit).join(', ')}">${vals.map((v, i) => `<div class="b"><span class="tip">${v}${unit}</span><i style="height:${Math.max(4, (v / max) * 130)}px"></i></div>`).join('')}</div>
  <div class="bar-labels">${labels.map((l) => `<span>${l}</span>`).join('')}</div>`
}

/* ---------- Public site chrome ---------- */
const PUBLIC_NAV = [['Discover', '#/discover'], ['Events', '#/events'], ['Organizations', '#/organizations'], ['Map', '#/map'], ['Stories', '#/media'], ['About', '#/about']]
W.header = (active) => `<header class="site-header"><div class="container inner">
  ${W.logo()}
  <nav class="nav desktop-only" aria-label="Primary">${PUBLIC_NAV.map(([l, h]) => `<a href="${h}" class="${active === h ? 'is-active' : ''}">${l}</a>`).join('')}</nav>
  <div class="row gap-8">
    <a href="#/login/volunteer" class="btn btn--ghost btn--sm desktop-only">Sign in</a>
    <a href="#/register" class="btn btn--primary btn--sm">Join</a>
    <button class="icon-btn mobile-only" data-action="toggle-menu" aria-expanded="false" aria-controls="mobile-menu" aria-label="Menu">${I('menu')}</button>
  </div></div>
  <nav id="mobile-menu" class="mobile-menu" hidden aria-label="Mobile">${PUBLIC_NAV.map(([l, h]) => `<a href="${h}" class="${active === h ? 'is-active' : ''}">${l}</a>`).join('')}<a href="#/emergency">Emergency network</a><a href="#/login/volunteer">Sign in</a></nav>
</header>`

W.footer = () => `<footer class="site-footer"><div class="container">
  <div class="footer-grid">
    <div class="footer-col">${W.logo(true)}<p class="small" style="margin:6px 0 0;color:#a9c7bd;max-width:300px">One profile for volunteering, internships and community programmes — with experience confirmed by verified organizations.</p>
      <div class="social mt-8" aria-label="Official social channels">${['facebook', 'instagram', 'linkedin', 'youtube', 'xbrand'].map((s) => `<span class="is-off" title="Official ${s === 'xbrand' ? 'X' : s} link — to be supplied by Worldkin">${I(s, 17)}</span>`).join('')}</div>
      <span class="caption" style="color:#7fa59a">Social links appear only once official accounts are supplied.</span></div>
    <div class="footer-col"><h4>Discover</h4><a href="#/discover">Opportunities</a><a href="#/events">Events</a><a href="#/organizations">Organizations</a><a href="#/map">Map</a><a href="#/media">Stories &amp; media</a></div>
    <div class="footer-col"><h4>For volunteers</h4><a href="#/register">Create an account</a><a href="#/login/volunteer">Sign in</a><a href="#/v/passport">Experience passport</a><a href="#/emergency">Emergency network</a></div>
    <div class="footer-col"><h4>For organizations</h4><a href="#/register?role=org">Register an organization</a><a href="#/login/org">Organization sign in</a><a href="#/about#verification">How verification works</a></div>
    <div class="footer-col"><h4>Trust &amp; platform</h4><a href="#/about">About Worldkin</a><a href="#/about#contact">Contact</a><a href="#/about#faq">FAQ</a><a href="#/about#privacy">Privacy policy</a><a href="#/about#terms">Terms of service</a></div>
  </div>
  <div class="footer-bottom"><span>© 2026 Worldkin Roster · HACK THE VIBE 2026 · World Problem Solver track</span><span>Prototype — all figures and organizations are sample data.</span></div>
</div></footer>`

W.publicPage = (active, content) => W.header(active) + `<main id="main">${content}</main>` + W.footer()

/* ---------- Workspace shells (volunteer / organization / admin) ---------- */
const VOL_NAV = [['Overview', '#/v/dashboard', 'home'], ['Applications & offers', '#/v/applications', 'briefcase', 1], ['Calendar', '#/v/calendar', 'calendar'], ['Experience passport', '#/v/passport', 'award'], ['Certificates', '#/v/certificates', 'file-text'], ['Notifications', '#/v/notifications', 'bell', 2], ['Profile & settings', '#/v/profile', 'user']]
const ORG_NAV = [['Overview', '#/o/dashboard', 'home'], ['Opportunities', '#/o/opportunities', 'briefcase'], ['Applicants', '#/o/applicants', 'users', 3], ['Offers & shifts', '#/o/offers', 'calendar'], ['Attendance', '#/o/attendance', 'clipboard-check'], ['Reports', '#/o/reports', 'bar-chart'], ['Organization profile', '#/o/profile', 'building']]
const ADMIN_NAV = [['Overview', '#/a/overview', 'home', 'overview'], ['Organization verification', '#/a/verify', 'shield-check', 'verify', 2], ['User management', '#/a/users', 'users', 'users'], ['Content moderation', '#/a/moderation', 'flag', 'moderation', 4], ['Disputes & reviews', '#/a/disputes', 'scale', 'disputes', 1], ['Audit log', '#/a/audit', 'activity', 'audit'], ['Access management', '#/a/access', 'key', 'access']]

W.shell = ({ kind, active, content, title = '' }) => {
  let nav, sideCls = 'sidebar', who
  if (kind === 'volunteer') { nav = VOL_NAV; who = ['Nadia Rahman', 'Volunteer', 'NR'] }
  else if (kind === 'org') { nav = ORG_NAV; who = ['Dhaka Food Relief (Sample)', 'Organization admin', 'DF'] }
  else { nav = ADMIN_NAV.filter((n) => W.ADMIN_PERMS[n[3]].includes(W.state.adminRole)); sideCls += ' sidebar--dark'; who = [W.ADMINS[W.state.adminRole], 'Restricted workspace', 'AD'] }
  const links = nav.map(([l, h, ic, x, n]) => { const cnt = kind === 'admin' ? n : x; return `<a href="${h}" class="side-link ${active === h ? 'is-active' : ''}" ${active === h ? 'aria-current="page"' : ''}>${I(ic, 18)}<span>${l}</span>${cnt ? `<span class="count">${cnt}</span>` : ''}</a>` }).join('')
  const orgSwitch = kind === 'org' ? `<div class="side-group">Organization</div><button class="side-link" data-action="org-switch" style="border:0;background:none;width:100%;cursor:pointer">${W.avatar('DF', 26)}<span style="text-align:left">Dhaka Food Relief<br><span class="caption">Switch organization</span></span>${I('chevron-down', 16)}</button>` : ''
  const roleSwitch = kind === 'admin' ? `<div class="side-group">Signed in as</div><label class="sr-only" for="role-sel">Admin role (prototype)</label>
    <select id="role-sel" class="select" data-action="admin-role" style="background:rgba(255,255,255,.08);color:#fff;border-color:rgba(255,255,255,.15)">${Object.entries(W.ADMINS).map(([k, v]) => `<option value="${k}" ${W.state.adminRole === k ? 'selected' : ''} style="color:#000">${v}</option>`).join('')}</select>
    <span class="caption" style="color:#7fa59a;padding:4px 2px">Prototype switch — real roles are assigned in Access management.</span>` : ''
  const bottom = nav.slice(0, 5).map(([l, h, ic]) => `<a href="${h}" class="${active === h ? 'is-active' : ''}">${I(ic, 20)}<span>${l.split(' ')[0]}</span></a>`).join('')
  return `<div class="shell">
    <aside class="${sideCls}" aria-label="${kind} navigation">${W.logo(kind === 'admin')}${orgSwitch}${roleSwitch}<div class="side-group">Workspace</div>${links}
      <div class="side-foot"><div class="row gap-12" style="padding:8px">${W.avatar(who[2], 36, true)}<div class="stack" style="min-width:0"><span class="small" style="font-weight:600;line-height:1.3">${who[0]}</span><span class="caption" style="${kind === 'admin' ? 'color:#7fa59a' : ''}">${who[1]}</span></div></div>
      <a href="#/home" class="side-link">${I('log-out', 18)}<span>Sign out</span></a></div></aside>
    <div class="stack" style="min-width:0">
      <div class="topbar"><div class="row gap-12" style="min-width:0"><span class="mobile-only">${W.logo()}</span><span class="desktop-only small muted">${title}</span></div>
        <div class="row gap-4">${kind !== 'admin' ? `<a href="#/discover" class="btn btn--ghost btn--sm desktop-only">${I('search', 16)}Find opportunities</a>` : `<span class="badge b-grey desktop-only">${I('lock', 14)}MFA verified</span>`}
          <a href="${kind === 'volunteer' ? '#/v/notifications' : kind === 'org' ? '#/o/dashboard' : '#/a/overview'}" class="icon-btn" aria-label="Notifications, 2 unread">${I('bell')}<span class="dot-unread" style="position:absolute;top:9px;right:9px"></span></a></div></div>
      <main id="main" class="main">${content}</main>
      <nav class="bottom-nav" aria-label="Workspace">${bottom}</nav>
    </div></div>`
}
W.pageHead = (title, sub = '', actions = '', crumbs = '') => `<div>${crumbs}<div class="page-head"><div><h1 class="h2">${title}</h1>${sub ? `<p>${sub}</p>` : ''}</div>${actions ? `<div class="row wrap gap-8">${actions}</div>` : ''}</div></div>`

/* ---------- Contact panel (shows ONLY published fields) ---------- */
W.contactPanel = (key, opts = {}) => {
  const c = W.CONTACT_STATES[key] || {}
  const items = []
  if (c.email) items.push(`<a class="contact-item" href="mailto:${c.email}"><span class="ci">${I('mail', 18)}</span><span><strong>Email the organization</strong><small>${c.email}</small></span></a>`)
  if (c.phone) items.push(`<a class="contact-item" href="tel:${c.phone.replace(/\s/g, '')}"><span class="ci">${I('phone', 18)}</span><span><strong>Call</strong><small>${c.phone}</small></span></a>`)
  if (c.website) items.push(`<a class="contact-item" href="https://${c.website}" target="_blank" rel="noopener noreferrer"><span class="ci">${I('globe', 18)}</span><span><strong>Official website</strong><small>${c.website} ${I('external', 12)}</small></span></a>`)
  if (c.address && !opts.compact) items.push(`<div class="contact-item"><span class="ci">${I('map-pin', 18)}</span><span><strong>Office</strong><small>${c.address}</small></span></div>`)
  const social = c.social ? `<div class="row gap-8 mt-8">${Object.keys(c.social).map((s) => `<a class="icon-btn" style="border:var(--border)" href="#" aria-label="Official ${s} page">${I(s, 18)}</a>`).join('')}</div>` : ''
  const body = items.length
    ? `<div class="contact-list">${items.join('')}</div>${social}`
    : `<p class="small muted" style="margin:0">This organization hasn’t published contact details. You can still view its opportunities and apply through Worldkin.</p>
       <a href="#/discover" class="btn btn--secondary btn--sm mt-12">${I('briefcase', 16)}View opportunities</a>`
  return `<div class="card card-pad stack gap-12"><div class="row between gap-8"><h2 class="h4">Contact the organization</h2>${c.updated ? W.badge(c.updated, 'green', 'check') : ''}</div>
    ${body}<p class="caption" style="margin:0">${I('lock', 12)} Only details the organization chose to publish are shown. Worldkin has no in-app messaging.</p></div>`
}

/* ---------- Toast + modal ---------- */
W.toast = (msg, icon = 'check-circle') => {
  const t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status')
  t.innerHTML = I(icon, 18) + `<span>${W.esc(msg)}</span>`
  document.getElementById('toasts').appendChild(t); setTimeout(() => t.remove(), 3600)
}
W.modal = ({ title, body, confirm = 'Confirm', danger = false, onConfirm }) => {
  const root = document.getElementById('modal-root'), prev = document.activeElement
  root.innerHTML = `<div class="modal-backdrop" data-close><div class="modal" role="dialog" aria-modal="true" aria-labelledby="mt">
    <h2 id="mt" class="h3">${title}</h2><div class="small" style="color:var(--ink-700)">${body}</div>
    <div class="modal-actions"><button class="btn btn--secondary" data-close>Cancel</button><button class="btn ${danger ? 'btn--danger' : 'btn--primary'}" data-ok>${confirm}</button></div></div></div>`
  const close = () => { root.innerHTML = ''; prev && prev.focus() }
  root.querySelectorAll('[data-close]').forEach((el) => el.addEventListener('click', (e) => { if (e.target === el) close() }))
  root.querySelector('[data-ok]').addEventListener('click', () => { close(); onConfirm && onConfirm() })
  root.addEventListener('keydown', (e) => { if (e.key === 'Escape') close() }, { once: true })
  root.querySelector('[data-ok]').focus()
}
